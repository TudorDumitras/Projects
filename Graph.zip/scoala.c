#include <stdio.h>
#include <stdlib.h>

//Structurile pentru orase si drumuri (explicate mai bine in README)
typedef struct Oras {
	struct Drum *roads;
	int id;
	int vz;
} Oras;

typedef struct Drum {
	struct Drum *next;
	struct Oras *city;
} Drum;

//Eliberez memoria ocupata de un graf
void FreeGraf(Oras **oras, int no)
{
	int i;

	Drum *aux;

	for(i=0; i<no; i++)
	{
		aux = oras[i]->roads;

		while(oras[i]->roads != NULL)
		{
			aux = oras[i]->roads;
			oras[i]->roads = oras[i]->roads->next;
			free(aux);
		}

		free(oras[i]);
	}

	free(oras);
}

//Parcurg recursiv nodurile dintr-un element conex
void Parcurge(Oras *oras)
{
	oras->vz = 1;

	while(oras->roads != NULL)
	{
		if(oras->roads->city->vz == 0)
			Parcurge(oras->roads->city);
		
		oras->roads = oras->roads->next;
	}
}

//Aflu numarul de elemente conexe
int Conex(Oras **oras, int no) {

	int cnx=0, i;
	
	for(i=0; i<no; i++)
	{
		if(oras[i]->vz == 0)
		{
			Parcurge(oras[i]);
			cnx++;
		}
	}
	
	return cnx;
}

//Realizeaza drumurile din graf, si aloca memorie pentru ele
Oras** Roads(Oras **oras, int s, int d) {

	Drum *aux = (Drum*)malloc(sizeof(Drum));

	if(oras[s-1]->roads == NULL)
	{
		aux->next = NULL;
		oras[s-1]->roads = aux;
	}
	else 
	{
		aux->next = oras[s-1]->roads;
		oras[s-1]->roads = aux;
	}
		
	aux->city = oras[d-1];

	return oras;
}

//Realizeaza orasele din graf, si aloca memorie pentru ele
Oras** Graf(int no) {

	int i;
	//Se aloca memorie pentru un vector de liste
	Oras **oras = (Oras**)calloc(no, sizeof(Oras*));

	for(i=0; i<no; i++)
	{
		//Se aloca memorie pentru o lista si se modifica elementele sale
		if(i==0)
		{
			oras[i] = (Oras*)malloc(sizeof(Oras));
			oras[i]->roads = NULL;
			oras[i]->id = i;
			oras[i]->vz = 0;
		}
		else
		{
			oras[i] = (Oras*)malloc(sizeof(Oras));
			oras[i]->roads = NULL;
			oras[i]->id = i;
			oras[i]->vz = 0;
		}
	}

	return oras;
}

int main() {

	int k, no, nd, cd, cs, s, d, i, j, ct, cnx;

	FILE *in, *out;
	in = fopen("scoala.in", "r");
	out = fopen("scoala.out", "w");
	

	fscanf(in, "%d", &k);

	for(i=1; i<=k; i++)
	{
		fscanf(in, "%d", &no);
		fscanf(in, "%d", &nd);
		fscanf(in, "%d", &cd);
		fscanf(in, "%d", &cs);

		//Folosesc vector de liste
		Oras **graf = Graf(no);
		
		//Apelez functie ce realizeaza drumurile bidirectionale
		for(j=1; j<=nd; j++)
		{
			fscanf(in, "%d", &s);
			fscanf(in, "%d", &d);

			graf = Roads(graf, s, d);
			graf = Roads(graf, d, s);
		}

		//Calculez costul minim prin cele 2 formule deduse
		if(cs <= cd)
			ct = no*cs;
		else
		{
			cnx = Conex(graf, no);
			ct = cnx*cs + (no-cnx)*cd;
		}

		fprintf(out, "%d\n", ct);
		FreeGraf(graf, no);		
		
	}

	fclose(in);
	fclose(out);

	return 0;
}
