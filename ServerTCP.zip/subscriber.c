#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include "helpers.h"

void usage(char *file)
{
	fprintf(stderr, "Usage: %s server_address server_port\n", file);
	exit(0);
}

int main(int argc, char *argv[])
{
	int sockfd, n, ret, ret2;
	struct sockaddr_in serv_addr;
	char buffer[BUFLEN];
	fd_set read_fds;
	fd_set tmp_fds;
	int fdmax;	
	if (argc < 3) {
		usage(argv[0]);
	}
	//Initializez socket-ul TCP

	FD_ZERO(&read_fds);
	FD_ZERO(&tmp_fds);
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	DIE(sockfd < 0, "socket");

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(atoi(argv[3]));
	ret = inet_aton(argv[2], &serv_addr.sin_addr);
	DIE(ret == 0, "inet_aton");
	FD_SET(sockfd, &read_fds);
	FD_SET(STDIN_FILENO, &read_fds);
	ret = connect(sockfd, (struct sockaddr*) &serv_addr, sizeof(serv_addr));
	DIE(ret < 0, "connect");
	fdmax = sockfd;
	n = send(sockfd, argv[1], strlen(argv[1]), 0);
	DIE(n < 0, "send");

	while (1) {
		tmp_fds = read_fds; 
		ret2 = select(fdmax + 1, &tmp_fds, NULL, NULL, NULL);
		for (int i = 0; i <= fdmax; i++) {
			if (FD_ISSET(i, &tmp_fds)) {
				if (i == sockfd) {
					//Printeaza ce primeste de la server

					memset(buffer, 0, BUFLEN);
					n = recv(sockfd, buffer, sizeof(buffer), 0);
					if (n == 0) {
						close(sockfd);
						close(STDIN_FILENO);
						return 0;
					}

					printf("%s\n", buffer);

					//Daca primesti "exit" de la server se inchide
					if(buffer[0] == 'e' && buffer[1] == 'x' && buffer[2] == 'i' && buffer[3] == 't') {
						close(sockfd);
						close(STDIN_FILENO);
						return 0;
					}

				} else {

					//Trimit comanda de la tastatura si o imparte in mai multe stringuri
					char aux[BUFLEN];
					memset(buffer, 0, BUFLEN);
					memset(aux, 0, BUFLEN);
					fgets(buffer,BUFLEN,stdin);
					strcpy(aux, buffer);
					buffer[strlen(buffer)-1]='\0';
					char *command = strtok(aux, " ");

					//Verific corectitudinea unei comenzi

					if(strcmp(buffer, "exit")==0 || strcmp(command, "subscribe")==0 || strcmp(command, "unsubscribe")==0){
						char *sfCheck = strtok(NULL, " ");
						sfCheck = strtok(NULL, " ");
						if(strcmp(command, "subscribe")==0 && sfCheck == NULL) {
							printf("Command doesn't exist, try again.\n");
						} else {
							n = send(sockfd, buffer, strlen(buffer), 0);
							DIE(n < 0, "send");
						}
					}
					else {
						printf("Command doesn't exist, try again.\n");
					}
				}
			}
		}

	}

	close(sockfd);

	return 0;
}
