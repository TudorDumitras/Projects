#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <math.h>
#include "helpers.h"

//Structura informatiilor unui topic la care este abonat un cont
typedef struct SubTopic {
	int id;
	int SF;
	int lastM;
} SubTopic;

//Structura unui cont client TCP
typedef struct Account {
	char id[10];
	int sockid;
	int subs;
	SubTopic subTopics[100];
} Account;

//Structura unui Topic
typedef struct Topic {
	char name[50];
	char type[50][50];
	int csize;
	char content[50][1500];
	char address[50][21];
} Topic;

void usage(char *file)
{
	fprintf(stderr, "Usage: %s server_port\n", file);
	exit(0);
}

int main(int argc, char *argv[])
{
	int sockfd, newsockfd, portno, sockudp;
	char buffer[BUFLEN];
	struct sockaddr_in serv_addr, cli_addr,from_station, udp_station;
	int n, i, ret, clients=0, j, retUDP, tsize=0;
	socklen_t clilen;
	Topic topics[100];
	Account accounts[100];

	fd_set read_fds;	// multimea de citire folosita in select()
	fd_set tmp_fds;		// multime folosita temporar
	int fdmax;			// valoare maxima fd din multimea read_fds

	if (argc < 2) {
		usage(argv[0]);
	}

	// se goleste multimea de descriptori de citire (read_fds) si multimea temporara (tmp_fds)
	FD_ZERO(&read_fds);
	FD_ZERO(&tmp_fds);

	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	sockudp = socket(PF_INET, SOCK_DGRAM, 0);
	DIE(sockfd < 0, "socket");

	portno = atoi(argv[1]);
	DIE(portno == 0, "atoi");

	//Initializez socket-ii TCP si UDP
	memset((char *) &serv_addr, 0, sizeof(serv_addr));
	serv_addr.sin_family = AF_INET;
	serv_addr.sin_port = htons(portno);
	serv_addr.sin_addr.s_addr = INADDR_ANY;

	udp_station.sin_family = AF_INET;
    udp_station.sin_port = htons(portno);
    udp_station.sin_addr.s_addr = INADDR_ANY;


	ret = bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(struct sockaddr));
	retUDP = bind(sockudp, (const struct sockaddr *) &udp_station, sizeof(struct sockaddr));

	DIE(ret < 0, "bind TCP");
	DIE(retUDP < 0, "bind UDP");

	ret = listen(sockfd, MAX_CLIENTS);
	DIE(ret < 0, "listen");

	// se adauga noul file descriptor (socketul pe care se asculta conexiuni) in multimea read_fds
	FD_SET(sockfd, &read_fds);
	FD_SET(STDIN_FILENO, &read_fds);
	FD_SET(sockudp, &read_fds);
	fdmax = sockfd;

	if(sockudp > sockfd)
		fdmax = sockudp;
	else
		fdmax = sockfd;

	unsigned int size = sizeof(struct sockaddr_in);

	while (1) {
		tmp_fds = read_fds; 
		
		ret = select(fdmax + 1, &tmp_fds, NULL, NULL, NULL);
		DIE(ret < 0, "select");

		for (i = 0; i <= fdmax; i++) {
			if (FD_ISSET(i, &tmp_fds)) {
				if (i == sockfd) {
					// a venit o cerere de conexiune pe socketul inactiv (cel cu listen),
					// pe care serverul o accepta

					clilen = sizeof(cli_addr);
					newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen);
					DIE(newsockfd < 0, "accept");

					// se adauga noul socket intors de accept() la multimea descriptorilor de citire
					FD_SET(newsockfd, &read_fds);
					if (newsockfd > fdmax) { 
						fdmax = newsockfd;
					}

				} else if (i == sockudp) { 
					memset(buffer, 0, BUFLEN);
					int date;
					//Primesc o conexiune d tip UDP, modific datele primite si stochez informatiile in topic
					if((date = recvfrom(sockudp, buffer, BUFLEN, 0, (struct sockaddr *) &from_station, &size)) >=0) {
						int exists=0;
						char auxName[50];
						int auxType = buffer[50];
						char auxContent[1500];
						char auxT[50];
						char typeName[50];
						memcpy(auxName, buffer, 50);

						if(auxType == 0) {
							memcpy(auxContent, buffer+51, (date-51));
							strcpy(typeName, "INT");
							uint32_t data;
							char semn = 0;
							memcpy(&data, auxContent + 1, sizeof(uint32_t));
							memcpy(&semn, auxContent, 1);
							data = ntohl(data);
							sprintf(auxT, "%u", data);

							if(semn == 1) {
								strcpy(auxContent, "-");
								strcat(auxContent, auxT);
							}
							else {
								strcpy(auxContent, auxT);
							}
						} else if(auxType == 1) {
							memcpy(auxContent, buffer+51, (date-51));
							strcpy(typeName, "SHORT REAL");
							uint16_t data;
							memcpy(&data, auxContent, sizeof(uint16_t));
							data = ntohs(data);
							sprintf(auxT, "%.2f", (double)data/100);
							strcpy(auxContent, auxT);
						} else if(auxType == 2) {
							memcpy(auxContent, buffer+51, (date-51));
							strcpy(typeName, "FLOAT");
							uint32_t data;
							char semn = 0;
							uint8_t putere;
							float final;

							memcpy(&data, auxContent + 1, sizeof(uint32_t));
							memcpy(&semn, auxContent, 1);				    		
							memcpy(&putere, auxContent + 1 + sizeof(uint32_t), sizeof(uint8_t));
							data = ntohl(data);
							final = 1 / pow(10, putere);
							final = data * final;

							if(semn == 1) {
								strcpy(auxContent, "-");
								sprintf(auxT, "%.4f", final);
								strcat(auxContent, auxT);
							}
							else {
								sprintf(auxT, "%.4f", final);
								strcpy(auxContent, auxT);
							}

						} else {
							strcpy(auxContent, buffer+51);
							strcpy(typeName, "STRING");
						}

						char *udpIP = inet_ntoa(from_station.sin_addr);
						char udpPort[5];
						sprintf(udpPort, "%d", ntohs(from_station.sin_port));

						for(int j=0; j<tsize; j++) {
							if(strcmp(auxName, topics[j].name) == 0){
								int aux = topics[j].csize;
								strcpy(topics[j].content[aux], auxContent);
								strcpy(topics[j].address[aux], udpIP);
								strcat(topics[j].address[aux], ":");
								strcat(topics[j].address[aux], udpPort);
								strcpy(topics[j].type[aux], typeName);
								for(int k=0; k<clients; k++) {
									if(accounts[k].sockid != -1) {
										for(int z=0; z<accounts[k].subs; z++) {
											if(accounts[k].subTopics[z].id == j) {
												strcpy(buffer, topics[j].address[aux]);
												strcat(buffer, " - ");
												strcat(buffer, topics[j].name);
												strcat(buffer, " - ");
												strcat(buffer, topics[j].type[aux]);
												strcat(buffer, " - ");
												strcat(buffer, topics[j].content[aux]);
												n = send(accounts[k].sockid, buffer, strlen(buffer), 0);	
												DIE(n < 0, "send on server");
												accounts[k].subTopics[z].lastM++;
												break;
											}
										}
									}
								}
								topics[j].csize++;
								exists = 1;
							}
						}
						if (exists == 0) {
							memcpy(topics[tsize].name, buffer, 50);
							strcpy(topics[tsize].type[0], typeName);
							strcpy(topics[tsize].content[0], auxContent);
							strcpy(topics[tsize].address[0], udpIP);
							strcat(topics[tsize].address[0], ":");
							strcat(topics[tsize].address[0], udpPort);
							topics[tsize].csize = 1;
							tsize++; 
						}
					}
				} else if (i == STDIN_FILENO) {
					memset(buffer, 0, BUFLEN);
					scanf("%s", buffer);
					//Comanda de inchidere a serverului + SHOW care arata lista conturile inregistrate de server

					if(buffer[0] == 'e' && buffer[1] == 'x' && buffer[2] == 'i' && buffer[3] == 't') {
						printf("Server has been shut down!\n");
						for (int k = 0; k <= fdmax; k++) {
							close(k);
						}
						return 0;
					}
					else if(buffer[0] == 'S' && buffer[1] == 'H' && buffer[2] == 'O' && buffer[3] == 'W') {
						printf("Showing all accounts:\n");
						printf("____________________________________________________________________\n");
						for(j=0;j<clients;j++) {
							printf("Account id: %s\n", accounts[j].id);
							printf("Socket id: %d\n", accounts[j].sockid);
							printf("Number of subscribtions: %d\n", accounts[j].subs);
							printf("Topics subscribed to and SF state: ");
							for(int k=0; k<accounts[j].subs; k++) {
								int aux = accounts[j].subTopics[k].id;
								printf("%s|SF:%d ", topics[aux].name,accounts[j].subTopics[k].SF);
							}
							printf("\n");
							printf("____________________________________________________________________\n");
						}
					}
					else {
						printf("Command doesn't exist, try again.\n");
					}
				} else {
					// s-au primit date pe unul din socketii de client,
					// asa ca serverul trebuie sa le receptioneze
					memset(buffer, 0, BUFLEN);
					n = recv(i, buffer, sizeof(buffer), 0);
					DIE(n < 0, "recv");

					if (n == 0) {
						// conexiunea s-a inchis
						for(int k=0; k<clients; k++) {
							if(accounts[k].sockid == i) {
								printf("Client %s disconnected\n", accounts[k].id);
								accounts[k].sockid = -1;
								break;
							}
						}
						close(i);
						
						// se scoate din multimea de citire socketul inchis 
						FD_CLR(i, &read_fds);
					} else {
						//Inchid conexiunea clientului tcp
						char *command = strtok(buffer, " ");
						if(strcmp(command, "exit") == 0) {
							for(int k=0; k<clients; k++) {
								if(accounts[k].sockid == i) {
									printf("Client %s disconnected.\n", accounts[k].id);
									accounts[k].sockid = -1;
									break;
								}
							}
							close(i);
							FD_CLR(i, &read_fds);
						}
						else if(strcmp(command, "subscribe") == 0){
							//Abonez un client la un topic
							char *tName = strtok(NULL, " ");
							char *flagSF = strtok(NULL, " ");
							int exists=0;
							int subscribed=0;
							int k, z;

							for(j=0;j<tsize;j++) {
								if(strcmp(tName, topics[j].name) == 0){

									for(k=0; k<clients; k++) {
										if(accounts[k].sockid == i) {
											for(z=0; z<accounts[k].subs; z++) {
												if(accounts[k].subTopics[z].id == j) {
													subscribed = 1;
													break;
												}
											}
											break;
										}
									}

									if(subscribed == 1) {
										if(atoi(flagSF) != accounts[k].subTopics[z].SF) {
											int aux = accounts[k].subTopics[z].id;
											accounts[k].subTopics[z].SF = atoi(flagSF);
											accounts[k].subTopics[z].lastM = topics[aux].csize;
											strcpy(buffer, "SF state changed to ");
											strcat(buffer, flagSF);
											n = send(i, buffer, strlen(buffer), 0);	
											DIE(n < 0, "send on server");
										} else { 
											strcpy(buffer, "Already subscribed to topic.");
											n = send(i, buffer, strlen(buffer), 0);	
											DIE(n < 0, "send on server");
										}
									}
									else {
										int aux = accounts[k].subs;
										accounts[k].subTopics[aux].id = j;
										accounts[k].subTopics[aux].SF = atoi(flagSF);
										accounts[k].subTopics[aux].lastM = topics[j].csize;
										accounts[k].subs++;
										exists = 1;
									}

									break;
								}
							}

							if(exists == 1) {
								strcpy(buffer, "Subscribed to topic.");
								n = send(i, buffer, strlen(buffer), 0);	
								DIE(n < 0, "send on server");
							}
							else if(subscribed==0) {
								strcpy(buffer, "The topic doesn't exist.");
								n = send(i, buffer, strlen(buffer), 0);	
								DIE(n < 0, "send on server");
							}
						}
						else if(strcmp(command, "unsubscribe") == 0){
							//Dezabonez un client de la un topic
							char *tName = strtok(NULL, " ");
							int exists=0;
							int subscribed=0;
							int k, z;

							for(j=0;j<tsize;j++) {
								if(strcmp(tName, topics[j].name) == 0) {

									for(k=0; k<clients; k++) {
										if(accounts[k].sockid == i) {
											for(z=0; z<accounts[k].subs; z++) {
												if(accounts[k].subTopics[z].id == j) {
													subscribed = 1;
													break;
												}
											}
											break;
										}
									}

									if(subscribed == 1) {
										for(z=z+1; z<accounts[k].subs; z++) {
											accounts[k].subTopics[z-1] = accounts[k].subTopics[z];
										}
										accounts[k].subs--;
									}
									else {
										strcpy(buffer, "You can't unsubscribe from a topic you are not subscribed to.");
										n = send(i, buffer, strlen(buffer), 0);	
										DIE(n < 0, "send on server");
									}

									exists = 1;
									break;
								}
							}

							if(exists == 1 && subscribed == 1) {
								strcpy(buffer, "Unsubscribed from topic.");
								n = send(i, buffer, strlen(buffer), 0);	
								DIE(n < 0, "send on server");
							}
							else if(exists == 0) {
								strcpy(buffer, "The topic doesn't exist.");
								n = send(i, buffer, strlen(buffer), 0);	
								DIE(n < 0, "send on server");
							}
						}
						else {
							//Inregisgtrez un cont nou sau reconectez unul existent
							int registered=0;
							int k;
							char *tcpIP = inet_ntoa(cli_addr.sin_addr);
							char tcpPort[5];
							sprintf(tcpPort, "%d", ntohs(cli_addr.sin_port));

							for(k=0; k<clients; k++) {
								if(strcmp(buffer, accounts[k].id)==0) {
									registered = 1;
									break;
								}
							}

							if(registered == 1) {
								printf("Client %s reconnected from %s:%s.\n", buffer, tcpIP, tcpPort);
								accounts[k].sockid = i;
								strcpy(buffer, "Welcome back! Loading missed content...\n");
								n = send(i, buffer, strlen(buffer), 0);	
								DIE(n < 0, "send on server");

								for(int z=0; z<accounts[k].subs; z++) {
									if(accounts[k].subTopics[z].SF == 1) {
										int lm=accounts[k].subTopics[z].lastM;
										int aux=accounts[k].subTopics[z].id;
										int cs=topics[aux].csize;
										for (int x = lm; x < cs; x++)
										{
											strcpy(buffer, topics[aux].address[x]);
											strcat(buffer, " - ");
											strcat(buffer, topics[aux].name);
											strcat(buffer, " - ");
											strcat(buffer, topics[aux].type[x]);
											strcat(buffer, " - ");
											strcat(buffer, topics[aux].content[x]);
											strcat(buffer, "\n");
											n = send(accounts[k].sockid, buffer, strlen(buffer), 0);	
											DIE(n < 0, "send on server");
										}
										accounts[k].subTopics[z].lastM = topics[aux].csize;
									}
								}
							}
							else {
								printf("New client %s connected from %s:%s.\n", buffer, tcpIP, tcpPort);
								strcpy(accounts[clients].id, buffer);
								accounts[clients].sockid = i;
								accounts[clients].subs= 0;
								clients++;
								strcpy(buffer, "Welcome, you have been registered!");
								n = send(i, buffer, strlen(buffer), 0);	
								DIE(n < 0, "send on server");
							}
						}
					}
				}
			}
		}
	}

	close(sockfd);
	close(sockudp);

	return 0;
}
