% Dumitras Tudor-Ionut - 313CD

function [A_k, S] = cerinta4(name, k)

  %Se creaza matricea de pixeli si se transforma valorile in numere reale
  A = imread(name);
  A = double(A);
  [n, m] = size(A);
  
  %Se calculeaza media pe linii si noile valori ale matricii A
  for i = 1:n
    s = 0;
    
    for j = 1:m
      s = s + A(i, j);
    endfor 
    y(i) = s/m;
  endfor
  
  for i = 1:n
    for j = 1:m
      A(i, j) = A(i, j) - y(i);
    endfor 
  endfor
  
  %Se calculeaza matricea Z si matricile V si S prin functia eig
  Z = 1/(m-1)*A*A';
  
  [V, S] = eig(Z);
  
  %Se calculeaza matricea W in functie de k, matricea Y si noua matrice A
  for i = 1:n
    for j = 1:k
      W(i, j) = V(i, j);
    endfor 
  endfor
  
  Y = W'*A;
  A_k = W*Y + y';
  
endfunction