% Dumitras Tudor-Ionut - 313CD

function A_k = cerinta1(name, k)

    %Se creaza matricea de pixeli si se afla matricile U, S si V prin functia svd
    A = imread(name);
    
    [U, S, V] = svd(A);
    
    V = V';
    
    [n, m] = size(A);

    %Se calculeaza noile matrici U, S si V in functie de k si aflu noua matrice A
    for i = 1:n
      for j = 1:k
        U_k(i, j) = U(i, j);
      endfor
    endfor
    
    for i = 1:k
      for j = 1:k
        S_k(i, j) = S(i, j);
      endfor
    endfor
    
    for i = 1:k
      for j = 1:m
        V_k(i, j) = V(i, j);
      endfor
    endfor
    
    A_k = U_k*S_k*V_k;
      
endfunction