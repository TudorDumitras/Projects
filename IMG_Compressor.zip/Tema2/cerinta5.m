% Dumitras Tudor-Ionut - 313CD

function cerinta5()
  
    %Se alege numele imaginii si valoarea lui k
    name = "image3.gif";
    k = 25;
    
    %Se creaza matricea de pixeli si se afla matricile U, S si V prin functia svd
    A = imread(name);
    [n, m] = size(A);
    
    %Se afla S si se creaza graficul valorilor de pe diagonala principala
    [B, S] = cerinta3(name, k);
    
    subplot(2, 2, 1)
    plot(diag(S));
    
    
    
    %Se calculeaza vectorul informatiilor date de primele k valori singulare si se creaza graficul
    for i = 1:k
      s1 = 0;
      s2 = 0;
    
      for j = 1:i
       s1 += S(j, j);
      endfor
     
      for j = 1:min(n, m)
        s2 += S(j, j);
      endfor
    
      kinfo(i) = s1/s2;
    endfor
    
    subplot(2, 2, 2)
    plot(kinfo);
    
    
    %Se calculeaza vectorul erorilor aproximarilor si se creaza graficul
    for i = 1:k
      [B S] = cerinta3(name, i);
      B = double(B);
      A = double(A);
      sa = 0;
      
      for x = 1:n
        for y = 1:m
          sa += (A(x, y) - B(x, y))*(A(x, y) - B(x, y));
        endfor
      endfor
      
      ea(i) = sa/(m*n);
    endfor
    
    subplot(2, 2, 3);
    plot(ea);
    
    
    %Se calculeaza vectorul ratelor de compresie a datelor si se creaza graficul
    for i = 1:k
      rc(i) = (m*i + n*i + i)/m*n;
    endfor
    
    subplot(2, 2, 4);
    plot(rc);
  
endfunction