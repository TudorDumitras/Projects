package utils;

public enum OperationType {
    // TODO add vcs commands
    CAT,
    CHANGEDIR,
    LIST,
    MAKEDIR,
    REMOVE,
    TOUCH,
    WRITETOFILE,
    PRINT,
    FILESYSTEM_INVALID_OPERATION,
    VCS_STATUS,
    VCS_BRANCH,
    VCS_COMMIT,
    VCS_CHECKOUT,
    VCS_LOG,
    VCS_ROLLBACK,
    VCS_INVALID_OPERATION,

}
