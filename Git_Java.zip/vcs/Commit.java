package vcs;

import filesystem.FileSystemSnapshot;
import utils.IDGenerator;

/**
 * Clasa ce imi retine fiecare comit de pe un branch
 */
public class Commit {
    private String msg;
    private int id;
    private FileSystemSnapshot Snapshot;

    public Commit(String m, FileSystemSnapshot activeSnapshot) {
        this.msg = m;
        this.Snapshot = activeSnapshot.cloneFileSystem();
        this.id = IDGenerator.generateCommitID();
    }

    public String getMsg() {
        return this.msg;
    }

    public int getId() {
        return this.id;
    }

    public FileSystemSnapshot getSnapshot() {
        return Snapshot;
    }
}
