package vcs;

import utils.ErrorCodeManager;
import utils.OperationType;

import java.util.ArrayList;

public class RollbackOperation extends VcsOperation {

    public RollbackOperation(OperationType type, ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }

    /**
     * Reactualizez snapshot-ul curent cu o copie anterioara
     * Curat Staged ChangewW
     */
    @Override
    public int execute(Vcs vcs) {
        vcs.setActiveSnapshot(vcs.getHead().getCommits()
                .get(vcs.getHead().getCommits().size() - 1).getSnapshot().cloneFileSystem());
        vcs.getStagedChanges().clear();

        return ErrorCodeManager.OK;
    }

}
