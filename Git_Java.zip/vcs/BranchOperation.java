package vcs;

import utils.ErrorCodeManager;
import utils.OperationType;

import java.util.ArrayList;

public class BranchOperation extends VcsOperation {

    public BranchOperation(OperationType type, ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }

    /**
     * Verifica daca mai exista un branch cu acelasi nume
     * Creeaza un branch nou
     */
    @Override
    public int execute(Vcs vcs) {
        operationArgs.remove(0);

        for (Branch b : vcs.getBranches()) {
            if (b.getName().equals(operationArgs.get(0)))
                return ErrorCodeManager.VCS_BAD_CMD_CODE;
        }

        vcs.newBranch(this.operationArgs.get(0));

        return ErrorCodeManager.OK;
    }

}
