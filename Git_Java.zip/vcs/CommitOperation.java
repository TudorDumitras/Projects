package vcs;

import utils.ErrorCodeManager;
import utils.OperationType;

import java.util.ArrayList;

public class CommitOperation extends VcsOperation {

    public CommitOperation(OperationType type, ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }

    /**
     * Verific daca s-au facut modificari de la ultimul commit
     * Adaug un nou commit si curat Staged Changes
     */
    @Override
    public int execute(Vcs vcs) {
        if (vcs.getStagedChanges().size() == 0)
            return ErrorCodeManager.VCS_BAD_CMD_CODE;

        operationArgs.remove(0);
        operationArgs.remove(0);

        String[] msg = operationArgs.toString().split("-m");

        vcs.getHead().newCommit(msg[0].replace("[", "")
                .replace("]", "").replace(",", ""), vcs.getActiveSnapshot());

        vcs.getStagedChanges().clear();

        return ErrorCodeManager.OK;
    }

}
