package vcs;

import utils.ErrorCodeManager;
import utils.OperationType;

import java.util.ArrayList;

public final class LogOperation extends VcsOperation {

    public LogOperation(OperationType type, ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }

    /**
     * Parcurg fiecare commit din branch-ul actual
     */
    @Override
    public int execute(Vcs vcs) {
        int i = 0;
        for (Commit c : vcs.getHead().getCommits()) {
            vcs.getOutputWriter().write("Commit id: " + c.getId() + "\n");
            vcs.getOutputWriter().write("Message: " + c.getMsg() + "\n");
            if (i != vcs.getHead().getCommits().size() - 1)
                vcs.getOutputWriter().write("\n");
            i++;
        }
        return ErrorCodeManager.OK;
    }

}
