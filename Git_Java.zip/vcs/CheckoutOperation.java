package vcs;

import utils.ErrorCodeManager;
import utils.OperationType;

import java.util.ArrayList;

public class CheckoutOperation extends VcsOperation {

    public CheckoutOperation(OperationType type, ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }

    /**
     * Verific daca s-a efectuat vreo schimbare
     * Verific daca se doreste mutarea pe un branch sau commit
     * Verific daca exista branch-ul/commit-ul
     * In caz contrar intorc eroarea potrivita
     */
    @Override
    public int execute(Vcs vcs) {
        if (vcs.getStagedChanges().size() != 0)
            return ErrorCodeManager.VCS_STAGED_OP_CODE;

        boolean exists = false;

        operationArgs.remove(0);

        if (operationArgs.get(0).equals("-c")) {
            operationArgs.remove(0);
            int j = -1;

            for (Commit c : vcs.getHead().getCommits()) {
                j++;
                if (c.getId() == Integer.valueOf(operationArgs.get(0))) {
                    vcs.setActiveSnapshot(c.getSnapshot().cloneFileSystem());
                    for (int i = vcs.getHead().getCommits().size() - 1; i != j; i--)
                        vcs.getHead().getCommits().remove(i);
                    exists = true;
                    break;
                }
            }

            if (!exists) {
                return ErrorCodeManager.VCS_BAD_PATH_CODE;
            }
        } else {

            for (Branch b : vcs.getBranches()) {
                if (b.getName().equals(operationArgs.get(0))) {
                    vcs.setHead(b);
                    exists = true;
                    break;
                }
            }

            if (!exists) {
                return ErrorCodeManager.VCS_BAD_CMD_CODE;
            }
        }

        return ErrorCodeManager.OK;
    }

}
