package vcs;

import utils.ErrorCodeManager;
import utils.OperationType;

import java.util.ArrayList;

public class StatusOperation extends VcsOperation {

    public StatusOperation(OperationType type, ArrayList<String> operationArgs) {
        super(type, operationArgs);
    }

    /**
     * Afisez branch-ul pe care ma aflu
     *  Parcurg fiecare element din Staged Changes si il afisez.
     */

    @Override
    public int execute(Vcs vcs) {
        vcs.getOutputWriter().write("On branch: " + vcs.getHead().getName() + "\n");
        vcs.getOutputWriter().write("Staged changes:\n");

        for (String c : vcs.getStagedChanges()) {
            vcs.getOutputWriter().write("\t" + c + "\n");
        }

        return ErrorCodeManager.OK;
    }

}
