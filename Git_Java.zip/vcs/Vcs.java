package vcs;

import filesystem.FileSystemOperation;
import filesystem.FileSystemSnapshot;
import utils.OutputWriter;
import utils.Visitor;

import java.util.ArrayList;
import java.util.List;

public final class Vcs implements Visitor {
    private final OutputWriter outputWriter;
    private FileSystemSnapshot activeSnapshot;
    private List<Branch> branches;
    private List<String> stagedChanges;
    private Branch head;


    /**
     * Vcs constructor.
     *
     * @param outputWriter the output writer
     */
    public Vcs(OutputWriter outputWriter) {
        this.outputWriter = outputWriter;
    }

    /**
     * Does initialisations.
     */
    public void init() {
        this.activeSnapshot = new FileSystemSnapshot(outputWriter);

        this.branches = new ArrayList<>();
        this.stagedChanges = new ArrayList<>();

        branches.add(new Branch("master"));
        branches.get(0).newCommit("First commit", this.activeSnapshot);
        this.head = branches.get(0);
    }

    /**
     * Visits a file system operation.
     *
     * @param fileSystemOperation the file system operation
     * @return the return code
     */
    public int visit(FileSystemOperation fileSystemOperation) {
        return fileSystemOperation.execute(this.activeSnapshot);
    }

    /**
     * Visits a vcs operation.
     *
     * @param vcsOperation the vcs operation
     * @return return code
     */
    @Override
    public int visit(VcsOperation vcsOperation) {
        return vcsOperation.execute(this);
    }

    //TODO methods through which vcs operations interact with this

    /**
     * Mai jos am metode de set si get pentru operatiile vcs de vcs
     */

    public void setStagedChanges(String change) {
        this.stagedChanges.add(change);
    }

    public Branch getHead() {
        return this.head;
    }

    public void setHead(Branch head) {
        this.head = head;
    }

    public FileSystemSnapshot getActiveSnapshot() {
        return activeSnapshot;
    }

    public void setActiveSnapshot(FileSystemSnapshot activeSnapshot) {
        this.activeSnapshot = activeSnapshot;
    }

    public List<Branch> getBranches() {
        return this.branches;
    }

    public void newBranch(String arg) {
        this.branches.add(new Branch(arg));
        this.branches.get(branches.size() - 1).setCommits(this.head.getCommits());
    }

    public OutputWriter getOutputWriter() {
        return outputWriter;
    }

    public List<String> getStagedChanges() {
        return this.stagedChanges;
    }
}
