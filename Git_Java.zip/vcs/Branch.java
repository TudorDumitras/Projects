package vcs;

import filesystem.FileSystemSnapshot;

import java.util.ArrayList;
import java.util.List;

/**
 * Clasa ce imi retine fiecare branch
 */
public class Branch {
    String name;
    private List<Commit> commits;

    public Branch(String n) {
        this.name = n;
        this.commits = new ArrayList<>();
    }

    public void newCommit(String m, FileSystemSnapshot activeSnapshot) {
        this.commits.add(new Commit(m, activeSnapshot));
    }

    public List<Commit> getCommits() {
        return this.commits;
    }

    public void setCommits(List<Commit> commitList) {
        this.commits = commitList;
    }

    public String getName() {
        return this.name;
    }
}
