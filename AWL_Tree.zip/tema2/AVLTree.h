#ifndef AVLTREE_H_
#define AVLTREE_H_

#include <stdlib.h>

#define MAX(a, b) (((a) >= (b))?(a):(b))
#define HEIGHT(x) ((x)?((x)->height):(0))

/*
  IMPORTANT!

  As we stick to pure C, we cannot use templates. We will just assume
  some type Item was previously defined.
 */
// -----------------------------------------------------------------------------

typedef struct node{
	void* elem;
	void* info;
	struct node *pt;
	struct node *lt;
	struct node *rt;
	struct node* next;
	struct node* prev;
	struct node* end;
	long height;
}TreeNode;

typedef struct TTree{
	TreeNode *root;
	void* (*createElement)(void*);
	void (*destroyElement)(void*);
	void* (*createInfo)(void*);
	void (*destroyInfo)(void*);
	int (*compare)(void*, void*);
	long size;
}TTree;


TTree* createTree(void* (*createElement)(void*), void (*destroyElement)(void*),
		void* (*createInfo)(void*), void (*destroyInfo)(void*),
		int compare(void*, void*)){
	// TODO: Cerinta 1
	/* 1. This tree does NOT have any sentinels!!!
	 * "root" is just a pointer to the actual root node.
	 * 
	 * 2. You must set all function pointers in the structure!!!
	 */

	TTree *tree = (TTree*)malloc(sizeof(TTree));

	tree->createElement = createElement;
	tree->destroyElement = destroyElement;
	tree->createInfo = createInfo;
	tree->destroyInfo = destroyInfo;
	tree->compare = compare;

	tree->root = NULL;
	tree->size = 0;

	return tree;
}

TreeNode* createTreeNode(TTree *tree, void* value, void* info){	
	// TODO: Cerinta 1
	/* Implementing and using this function
	 * will greatly improve your chances of 
	 * getting this to work.
	 */

	TreeNode* node = (TreeNode*)malloc(sizeof(TreeNode));

	node->elem = tree->createElement(value);
	node->info = tree->createInfo(info);

	node->pt = NULL;
	node->lt = NULL;
	node->rt = NULL;
	node->next = NULL;
	node->prev = NULL;
	node->end = NULL;
	node->height = 1;

	return node;

}

void destroyTreeNode(TTree *tree, TreeNode* node){
	// TODO: Cerinta 1
	/* Implementing and using this function
	 * will greatly improve your chances of 
	 * getting this to work.
	 */

	free(node->elem);
	free(node->info);

	free(node->pt);
	free(node->lt);
	free(node->rt);
	free(node->next);
	free(node->prev);
	free(node->end);

}


int isEmpty(TTree* tree){
	// TODO: Cerinta 1

	if(tree->root == NULL)
		return 1;
	else
		return 0;
}

TreeNode* search(TTree* tree, TreeNode* x, void* elem){

	// TODO: Cerinta 1
	return NULL;
}

TreeNode* minimum(TTree*tree, TreeNode* x){
	// TODO: Cerinta 1

	while (x->lt != NULL)
		x = x->lt;

	return x;

}

TreeNode* maximum(TTree* tree, TreeNode* x){
	// TODO: Cerinta 1

	while(x->rt != NULL)
	{
		x = x->rt;
	}

	return x;

}

TreeNode* successor(TTree* tree, TreeNode* x){
	// TODO: Cerinta 1
	return NULL;
}

TreeNode* predecessor(TTree* tree, TreeNode* x){
	// TODO: Cerinta 1
	return NULL;
}

void avlRotateLeft(TTree* tree, TreeNode* x){
	// TODO: Cerinta 1
	/* You may want to use the macros at the top of this file.
	 */

	TreeNode *y = x->rt;

	y->lt = x;
	y->pt = x->pt;
	x->pt = y;
	
	if(y->pt != NULL)
		y->pt->rt = y;
	else
		tree->root = y;

	y->lt->height = 1;

	TreeNode *aux = y->pt;

	while(aux != NULL)
	{
		if(aux->lt != NULL && aux->rt != NULL)
			if(aux->lt->height > aux->rt->height)
				aux->height = aux->lt->height + 1;
			else
				aux->height = aux->rt->height + 1;
		else if(aux->lt != NULL)
			aux->height = aux->lt->height + 1;
		else if(aux->rt != NULL)
			aux->height = aux->rt->height + 1;
		
		aux = aux->pt;
	}

}

void avlRotateRight(TTree* tree, TreeNode* y){
	// TODO: Cerinta 1
	/* You may want to use the macros at the top of this file.
	 */

	TreeNode *x = y->lt;

	x->rt = y;
	x->pt = y->pt;
	y->pt = x;

	if(y->pt != NULL)
		x->pt->lt = x;
	else
		tree->root = x;

	x->rt->height = 1;

	TreeNode *aux = x->pt;

	while(aux != NULL)
	{
		if(aux->lt != NULL && aux->rt != NULL)
			if(aux->lt->height > aux->rt->height)
				aux->height = aux->lt->height + 1;
			else
				aux->height = aux->rt->height + 1;
		else if(aux->lt != NULL)
			aux->height = aux->lt->height + 1;
		else if(aux->rt != NULL)
			aux->height = aux->rt->height + 1;
		
		aux = aux->pt;
	}

}


int avlGetBalance(TTree* tree, TreeNode *x){
	//TODO: // TODO: Cerinta 1

	/* Get AVL balance factor for node x.
	 * You may want to use the macros at the top of this file.
	 */ 

	if (x == NULL || (x->lt == NULL && x->rt == NULL))
		return 0;
	else if (x->lt == NULL)
		return (0 - x->rt->height);
	else if (x->rt == NULL)
		return x->lt->height;
	else
		return (x->lt->height - x->rt->height);

}


void avlFixUp(TTree* tree, TreeNode* y){
	//TODO: Cerinta 1
	/* Fix any unblance from this node to the top of tree
	 */

	if(tree->size <= 1)
	{
		return;
	}

	while(y != NULL)
	{	
		int balance = avlGetBalance(tree, y->pt);
		printf("%d ", balance);

		if(y->pt != NULL)
		{
			if(balance>1 && tree->compare(y->elem, y->pt->elem)==-1)
			{
				avlRotateRight(tree, y->pt);
				return;
			}

			if(balance>1 && tree->compare(y->elem, y->pt->elem)==1)
			{
				avlRotateLeft(tree, y->lt);
				avlRotateRight(tree, y);
				return;
			}

			if(balance<-1 && tree->compare(y->elem, y->pt->elem)==1)
			{
				avlRotateLeft(tree, y->pt);
				return;
			}
	
			if(balance<-1 && tree->compare(y->elem, y->pt->elem)==-1)
			{
				avlRotateRight(tree, y->rt);
				avlRotateLeft(tree, y);
				return;
			}
		}


		y = y->pt;
	}

}

void insert(TTree* tree, void* elem, void* info) {
	//TODO: Cerinta 1
	/*
	 * 1. Begin by implementing the normal BST insersion (no duplicates).
	 * 2. Fix any unbalance caused by this insertion as the last operation.
	 * 3. Now if this element is a duplicate all you have to do is to
	 *    inserted in the approapiate list. Inseting the duplicate at the
	 *    end of a list is easier and consistent!
	 */

	int end_tree=0;

	TreeNode *y = tree->root;
	TreeNode *z = createTreeNode(tree, elem, info);

	if(tree->root == NULL)
	{
		tree->root = z;
		tree->size++;
	}
	else
	{

		while(end_tree != 1)
		{
			if((y->lt == NULL && tree->compare(y->elem, elem) == 1))
			{
				y->lt = z;
				z->pt = y;
				end_tree = 1;
			}
			else if((y->rt == NULL && tree->compare(y->elem, elem) == -1))
			{
				y->rt = z;
				z->pt = y;
				end_tree = 1;
			}
			else
			{
				if(tree->compare(y->elem, elem) == 1)
					y = y->lt;
				else if(tree->compare(y->elem, elem) == -1)
					y = y->rt;
			}

		}

		y = z;

		while(y->pt != NULL)
		{
			y = y->pt;	
			
			if(y->lt != NULL && y->rt != NULL)
				if(y->lt->height > y->rt->height)
					y->height = y->lt->height + 1;
				else
					y->height = y->rt->height + 1;
			else if(y->lt != NULL)
				y->height = y->lt->height + 1;
			else if(y->rt != NULL)
				y->height = y->rt->height + 1;
		}


		tree->size++;

	}
	

	avlFixUp(tree, z);
	printf("\n");
}

void delete(TTree* tree, void* elem){

	//TODO: Cerinta 1
	/*
	 * 1. Begin by implementing the normal BST deletion (no duplicates).
	 * 2. Fix any unbalance caused by this insertion as the last operation.
	 * 3. Now what happends if the elem you are trining to delete has duplicates?
	 *    Is it easier to delete the duplicate? Which one?
	 *    What happends to the tree-list when you delete an elem with no duplicates?
	 *    
	 */	
}

void DestroyTreeHelper(TTree* tree, TreeNode* x) {

	if (x != NULL) 
	{
		DestroyTreeHelper(tree,x->lt);
		DestroyTreeHelper(tree,x->rt);
		destroyTreeNode(tree,x);
	}
}

void destroyTree(TTree* tree){
	//TODO: Cerinta 1
	/* What is the easiest way to get rid of all elements for this SPECIAL tree?
	 */

	DestroyTreeHelper(tree, tree->root->lt);
	free(tree->root);
	free(tree);

}


#endif /* AVLTREE_H_ */
