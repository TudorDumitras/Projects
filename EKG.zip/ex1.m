clear;
t = -10:0.01:10;
k = 20;
u = cos(100*t + pi/3);
h = exp(-k*t);
y = conv(u, h);
subpolot(3,1,1);
plot(y);