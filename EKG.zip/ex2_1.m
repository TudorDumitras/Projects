function [person_id] = ex2_1(input_signal, isrow)
    n = 90;
    id = 0;
    path ="C:\Users\dethbb\Desktop\TS\tema1\ECG-DB\";
    sound_data = zeros(n,5000);
    Fs = 500;
    k=100;
    T = 1/Fs;
    L = 5000;
    subplot(4,1,1)
    plot(input_signal);
    
    if isrow == 1
        h = highpass(input_signal, 0.2);
        input_signal = input_signal - h;
    end
    subplot(4,1,2)
    plot(input_signal);
    
    Y = fft(input_signal);
    P2 = abs(Y/L);
    P1 = P2(1:L/2+1);
    P1(2:end-1) = 2*P1(2:end-1);
    subplot(4,1,3)
    plot(P1);
    
    for i=1:n 
        if i<10
            source = sprintf('Person_0%d',i);
        else
            
            source = sprintf('Person_%d',i);
        end
        file = fullfile(strcat(path,source),"rec_1m.mat");
        valor = load(file);
        
        X = fft(valor.val(2,:));
        P4 = abs(X/L);
        P3(i,:) = P4(1:L/2+1);
        P3(i,2:end-1) = 2*P3(i,2:end-1);
    end
    
    
    min = norm(P3(1,:)-P1);
    person_id = 1;

    
    for i=2:n
        ne = norm(P3(i,:)-P1);
        if ne<min
            min = ne;
            person_id = i;
        end
    end
    
    subplot(4,1,4)
    plot(P3(person_id,:));
    
end