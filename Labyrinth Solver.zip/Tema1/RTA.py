import collections

states = {}
costs = collections.defaultdict(list)
visited_states = []


def get_next_states(state):
    return costs[state]


def apply_action(state):
    visited_states.append(state)


def real_time_iterative_deepening_a_star_rec(node, goal, distance, threshold, current_path, h):

    apply_action(node)
    current_path.append(node)

    if node == goal:
        return True, distance, current_path

    estimate = distance + abs(states[node][0][0] - states[goal][0][0]) + abs(states[node][0][1] - states[goal][0][1])
    if estimate > threshold:
        return False, estimate, current_path[:-1]

    min = float("inf")
    x = 0
    sorted_neightbours = []

    for state in get_next_states(node):
        aux_estimate = distance + costs[node][x][1] + abs(states[state[0]][0][0] - states[goal][0][0])\
                       + abs(states[state[0]][0][1] - states[goal][0][1])
        sorted_neightbours.append((state[0], x, aux_estimate))

        x += 1

    sorted_neightbours = sorted(sorted_neightbours, key=lambda x: x[2])

    for state in sorted_neightbours:
        if not states[state[0]][1] and state[0] not in visited_states:
            found, cost, current_path = real_time_iterative_deepening_a_star_rec(state[0], goal, distance + costs[node][state[1]][1], threshold,
                                                             current_path, h)
            if found:
                return True, cost, current_path
            elif cost < min:
                min = cost

    return False, min, current_path[:-1]


def real_time_iterative_deepening_a_star(statesMap, costsMap, start, goal, h):
    global states
    global costs
    states = statesMap
    costs = costsMap

    global visited_states
    threshold = abs(states[start][0][0] - states[goal][0][0]) + abs(states[start][0][1] - states[goal][0][1])
    while True:
        visited_states = []
        found, distance, optimal_path = real_time_iterative_deepening_a_star_rec(start, goal, 0, threshold, [], h)
        if distance == float("inf"):
            return -1, []
        elif found:
            return distance, optimal_path
        else:
            threshold = distance