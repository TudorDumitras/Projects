import collections

states = {}
costs = collections.defaultdict(list)
visited_states = []


def get_next_states(state):
    return costs[state]


def apply_action(state):
    visited_states.append(state)


def DLS(src, target, cost, current_path, maxCost):
    apply_action(src)
    current_path.append(src)

    if maxCost < 0:
        return False, maxCost, current_path[:-1]

    if src == target: return True, cost, current_path

    x = 0
    for state in get_next_states(src):
        if not states[state[0]][1] and state[0] not in visited_states:
            finished, new_cost, current_path = DLS(state[0], target, cost + costs[src][x][1], current_path,
                                                   maxCost - costs[src][x][1])
            if finished:
                return True, new_cost, current_path
        x += 1
    return False, maxCost, current_path[:-1]


def IDDFS(statesMap, costsMap, src, target, cost):
    global states
    global costs
    states = statesMap
    costs = costsMap

    global visited_states
    i = 0
    new_cost = 0

    while 1:
        last_cost = new_cost
        last_visited_states = visited_states
        visited_states = []
        finished, new_cost, optimal_path = DLS(src, target, cost, [], i)

        if finished:
            return new_cost, optimal_path
        if last_visited_states == visited_states and last_cost == new_cost:
            break
        i += 1
    return -1, []