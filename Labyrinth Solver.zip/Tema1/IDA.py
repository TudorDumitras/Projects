import collections

states = {}
costs = collections.defaultdict(list)
visited_states = []


def get_next_states(state):
    return costs[state]


def apply_action(state):
    visited_states.append(state)


def iterative_deepening_a_star_rec(node, goal, distance, threshold, current_path, h):
    apply_action(node)
    current_path.append(node)

    if node == goal:
        return True, distance, current_path

    estimate = distance + h(node, goal)
    if estimate > threshold:
        return False, estimate, current_path[:-1]

    min = float("inf")
    x = 0

    for state in get_next_states(node):
        if not states[state[0]][1] and state[0] not in visited_states:
            found, cost, current_path = iterative_deepening_a_star_rec(state[0], goal, distance + costs[node][x][1], threshold,
                                                             current_path, h)
            if found:
                return True, cost, current_path
            elif cost < min:
                min = cost
        x += 1

    return False, min, current_path[:-1]


def iterative_deepening_a_star(statesMap, costsMap, start, goal, h):
    global states
    global costs
    states = statesMap
    costs = costsMap

    global visited_states
    threshold = h(start, goal)

    while True:
        visited_states = []
        found, distance, optimal_path = iterative_deepening_a_star_rec(start, goal, 0, threshold, [], h)
        if distance == float("inf"):
            return -1, []
        elif found:
            return distance, optimal_path
        else:
            threshold = distance