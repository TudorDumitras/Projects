import collections

states = {}
costs = collections.defaultdict(list)
visited_states = []


def get_next_states(state):
    return costs[state]


def apply_action(state):
    visited_states.append(state)


def branch_and_bound_search(node, goal, cost, current_path):

    apply_action(node)
    current_path.append(node)
    if node == goal:
        return True, cost, current_path

    x = 0
    sorted_neightbours = []

    for state in get_next_states(node):
        aux_estimate = cost + costs[node][x][1]
        sorted_neightbours.append((state[0], x, aux_estimate))

        x += 1

    sorted_neightbours = sorted(sorted_neightbours, key=lambda x: x[2])

    for state in sorted_neightbours:
        if not states[state[0]][1] and state[0] not in visited_states:
            found, cost, current_path = branch_and_bound_search(state[0], goal, state[2], current_path)
            if found:
                return True, cost, current_path

    return False, -1, current_path[:-1]


def branch_and_bound(statesMap, costsMap, start, goal):
    global states
    global costs
    states = statesMap
    costs = costsMap

    global visited_states

    visited_states = []
    found, distance, optimal_path = branch_and_bound_search(start, goal, 0, [])
    return distance, optimal_path
