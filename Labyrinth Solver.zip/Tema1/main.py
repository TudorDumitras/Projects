import collections
from math import sqrt
import time
import matplotlib.pyplot as pyplot

from BnB import *
from IDA import *
from IDDFS import *
from RTA import *

mouse_pos_id = 0
cheese_pos_id = 0
states = {}
costs = collections.defaultdict(list)

labyrinth = []
def make_plot(path, title):
    Matrix = [[0 for x in range(30)] for y in range(30)]

    for state in states:
        if states[state][1]:
            Matrix[states[state][0][0]][states[state][0][1]] = 150
        else:
            Matrix[states[state][0][0]][states[state][0][1]] = 50

    for point in path:
         Matrix[states[point][0][0]][states[point][0][1]] = 200

    Matrix[states[mouse_pos_id][0][0]][states[mouse_pos_id][0][1]] = 256
    Matrix[states[cheese_pos_id][0][0]][states[cheese_pos_id][0][1]] = 256

    pyplot.imshow(Matrix, cmap='Greys', interpolation='nearest')
    pyplot.title(title)
    pyplot.show()

def init_env(filename):

    global mouse_pos_id
    global cheese_pos_id

    file = open(filename, "r+")
    line = file.readline()[:-1]
    line = line.split(', ')
    mouse_pos = (int(line[0]), int(line[1]))
    line = file.readline()[:-1]
    line = line.split(', ')
    cheese_pos = (int(line[0]), int(line[1]))

    state_no = int(file.readline())

    for x in range(state_no):
        line = file.readline()[:-1]
        line = line.split(', ')

        if (int(line[1]), int(line[2])) == mouse_pos:
            mouse_pos_id = int(line[0])

        if (int(line[1]), int(line[2])) == cheese_pos:
            cheese_pos_id = int(line[0])

        if len(line) == 3:
            states[int(line[0])] = ((int(line[1]), int(line[2])), False)
        else:
            states[int(line[0])] = ((int(line[1]), int(line[2])), True)

    costs_no = int(file.readline())

    for x in range(costs_no):
        line = file.readline()[:-1]
        line = line.split(', ')
        costs[int(line[0])].append((int(line[1]), int(line[2])))
        costs[int(line[1])].append((int(line[0]), int(line[2])))


def get_next_states(state):
    return costs[state]


def apply_action(state):
    visited_states.append(state)


def own_euristic(node1, node2):
    return (abs(states[node1][0][0] - states[node2][0][0]) * abs(states[node1][0][1] - states[node2][0][1]))/2


def euclidian_distance(node1, node2):
    return sqrt(pow(states[node1][0][0] - states[node2][0][0], 2) + pow(states[node1][0][1] - states[node2][0][1], 2))


def main():
    init_env("teste\input1.txt")

    start_time = time.time()
    cost, optimal_path = IDDFS(states, costs, mouse_pos_id, cheese_pos_id, 0)
    total_time = time.time() - start_time

    print("IDDFS RESULTS:")

    if cost > 0:
        print("Target is reachable from source, cost: " + str(cost))
        print("Lenght of optimal path: " + str(len(optimal_path)))
        print("Algorithm execution time: " + str(total_time))
    else:
        print("Target is NOT reachable from source")
    make_plot(optimal_path, "IDDFS")

    start_time = time.time()
    cost, optimal_path = iterative_deepening_a_star(states, costs, mouse_pos_id, cheese_pos_id, euclidian_distance)
    total_time = time.time() - start_time
    print("\nEuclidian IDA* RESULTS:")

    if cost > 0:
        print("Target is reachable from source, cost: " + str(cost))
        print("Lenght of optimal path: " + str(len(optimal_path)))
        print("Algorithm execution time: " + str(total_time))
    else:
        print("Target is NOT reachable from source")
    make_plot(optimal_path, "IDA* Euclidian Euristic")

    start_time = time.time()
    cost, optimal_path = real_time_iterative_deepening_a_star(states, costs, mouse_pos_id, cheese_pos_id,
                                                              euclidian_distance)
    total_time = time.time() - start_time
    print("\nEuclidian RTA* RESULTS:")

    if cost > 0:
        print("Target is reachable from source, cost: " + str(cost))
        print("Lenght of optimal path: " + str(len(optimal_path)))
        print("Algorithm execution time: " + str(total_time))
    else:
        print("Target is NOT reachable from source")
    make_plot(optimal_path, "RTA* Euclidian Euristic")

    start_time = time.time()
    cost, optimal_path = iterative_deepening_a_star(states, costs, mouse_pos_id, cheese_pos_id, own_euristic)
    total_time = time.time() - start_time
    print("\nOwn Euristic IDA* RESULTS:")

    if cost > 0:
        print("Target is reachable from source, cost: " + str(cost))
        print("Lenght of optimal path: " + str(len(optimal_path)))
        print("Algorithm execution time: " + str(total_time))
    else:
        print("Target is NOT reachable from source")
    make_plot(optimal_path, "IDA* Own Euristi Euristic")

    start_time = time.time()
    cost, optimal_path = real_time_iterative_deepening_a_star(states, costs, mouse_pos_id, cheese_pos_id,
                                                              own_euristic)
    total_time = time.time() - start_time
    print("\nOwn Euristic RTA* RESULTS:")

    if cost > 0:
        print("Target is reachable from source, cost: " + str(cost))
        print("Lenght of optimal path: " + str(len(optimal_path)))
        print("Algorithm execution time: " + str(total_time))
    else:
        print("Target is NOT reachable from source")
    make_plot(optimal_path, "RTA* Own Euristi Euristic")

    start_time = time.time()
    cost, optimal_path = branch_and_bound(states, costs, mouse_pos_id, cheese_pos_id)
    total_time = time.time() - start_time
    print("\nBranch and Bound RESULTS:")

    if cost > 0:
        print("Target is reachable from source, cost: " + str(cost))
        print("Lenght of optimal path: " + str(len(optimal_path)))
        print("Algorithm execution time: " + str(total_time))
    else:
        print("Target is NOT reachable from source")
    make_plot(optimal_path, "Branch and Bound")


if __name__ == "__main__":
    main()