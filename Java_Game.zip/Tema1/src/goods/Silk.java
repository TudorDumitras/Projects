package goods;

public class Silk extends Goods {

	public Silk() {
		this.id = 10;
		this.legal = false;
		this.profit = 9;
		this.penalty = 4;
		this.bonus = 9;
		this.bonusid = 1;
	}
}