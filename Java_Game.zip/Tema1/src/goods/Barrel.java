package goods;

public class Barrel extends Goods {

	public Barrel() {
		this.id = 12;
		this.legal = false;
		this.profit = 7;
		this.penalty = 4;
		this.bonus = 8;
		this.bonusid = 2;
	}
}