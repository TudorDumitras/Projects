package goods;

public class Goods {
	protected int id;
	protected boolean legal;
	protected int profit;
	protected int penalty;
	protected int bonus;
	protected int bonusid;

	public Goods() {
		this.id = -1;
	}

	public boolean getLegal() {
		return this.legal;
	}

	public int getBonus() {
		return bonus;
	}

	public int getBonusId() {
		return bonusid;
	}

	public int getPenalty() {
		return penalty;
	}

	public int getId() {
		return id;
	}

	public int getProfit() {
		return profit;
	}

	public void removeId() {
		this.id = -1;
	}
}