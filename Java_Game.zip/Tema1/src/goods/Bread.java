package goods;

public class Bread extends Goods {

	public Bread() {
		this.id = 2;
		this.legal = true;
		this.profit = 4;
		this.penalty = 2;
		this.bonus = 0;
	}
}