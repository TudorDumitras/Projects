package goods;

public class Cheese extends Goods {

	public Cheese() {
		this.id = 1;
		this.legal = true;
		this.profit = 3;
		this.penalty = 2;
		this.bonus = 0;
	}
}