package goods;

public class Apple extends Goods {

	public Apple() {
		this.id = 0;
		this.legal = true;
		this.profit = 2;
		this.penalty = 2;
		this.bonus = 0;
	}
}