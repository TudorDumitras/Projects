package goods;

public class Chicken extends Goods {

	public Chicken() {
		this.id = 3;
		this.legal = true;
		this.profit = 4;
		this.penalty = 2;
		this.bonus = 0;
	}
}