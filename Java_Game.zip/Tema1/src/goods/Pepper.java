package goods;

public class Pepper extends Goods {

	public Pepper() {
		this.id = 11;
		this.legal = false;
		this.profit = 8;
		this.penalty = 4;
		this.bonus = 8;
		this.bonusid = 3;
	}
}