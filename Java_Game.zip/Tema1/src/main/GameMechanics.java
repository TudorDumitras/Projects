package main;

import goods.*;
import player.*;

public class GameMechanics {
	public Player newPlayer(String strategy) {
		Player player = new Player();

		switch (strategy) {
			case "basic":
				player = new Basic();
				break;
			case "bribed":
				player = new Bribe();
				break;
			case "greedy":
				player = new Greedy();
				break;
			case "wizard":
				player = new Wizzard();
				break;
		}

		return player;
	}

	public Goods newGood(int id) {
		Goods good = new Goods();

		switch (id) {
			case 0:
				good = new Apple();
				break;
			case 1:
				good = new Cheese();
				break;
			case 2:
				good = new Bread();
				break;
			case 3:
				good = new Chicken();
				break;
			case 10:
				good = new Silk();
				break;
			case 11:
				good = new Pepper();
				break;
			case 12:
				good = new Barrel();
				break;
		}

		return good;
	}
}