package main;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import player.*;
import goods.*;


public final class Main {

    private static final class GameInputLoader {
        private final String mInputPath;

        private GameInputLoader(final String path) {
            mInputPath = path;
        }

        public GameInput load() {
            List < Integer > assetsIds = new ArrayList < > ();
            List < String > playerOrder = new ArrayList < > ();

            try {
                BufferedReader inStream = new BufferedReader(new FileReader(mInputPath));
                String assetIdsLine = inStream.readLine().replaceAll("[\\[\\] ']", "");
                String playerOrderLine = inStream.readLine().replaceAll("[\\[\\] ']", "");

                for (String strAssetId: assetIdsLine.split(",")) {
                    assetsIds.add(Integer.parseInt(strAssetId));
                }

                for (String strPlayer: playerOrderLine.split(",")) {
                    playerOrder.add(strPlayer);
                }
                inStream.close();


            } catch (IOException e) {
                e.printStackTrace();
            }
            return new GameInput(assetsIds, playerOrder);
        }
    }

    public static void main(final String[] args) {
        GameInputLoader gameInputLoader = new GameInputLoader(args[0]);
        GameInput gameInput = gameInputLoader.load();

        // TODO Implement the game logic.

        int i, j, card = 0, maxk, maxq;
        int playersNumber = gameInput.getPlayerNames().size();
        int rounds = 2 * playersNumber;
        GameMechanics mechanics = new GameMechanics();

        Player[] players = new Player[playersNumber];
        for (i = 0; i < playersNumber; i++) {
            players[i] = mechanics.newPlayer(gameInput.getPlayerNames().get(i));
            for (j = 0; j < 6; j++) {
                players[i].addCard(j, mechanics.newGood(gameInput.getAssetIds().get(card)));
                card++;
            }
        }

        int id;

        for (i = 0; i < rounds; i++) {
            if (i < playersNumber)
                id = i;
            else
                id = i - playersNumber;

            for (j = 0; j < playersNumber; j++) {
                if (j != id) {

                    if (players[j].getStrategy() == "GREEDY")
                        players[j].increaseParity();

                    players[j].createSack();
                    players[id].checkSack(players[j]);
                    players[j].sellGoods();
                    for (int k = 0; k < 6; k++) {
                        if (players[j].getGoodId(k) == -1) {
                            players[j].addCard(k, mechanics.newGood(gameInput.getAssetIds().get(card)));
                            card++;
                        }
                    }
                }
            }
        }

        int[] bonusk = {
                20,
                15,
                15,
                10
        };
        int[] bonusq = {
                10,
                10,
                10,
                5
        };
        for (i = 0; i < 4; i++) {
            maxk = 0;
            maxq = 0;

            for (j = 0; j < playersNumber; j++) {
                if (players[j].getType(i) > maxk) {
                    maxq = maxk;
                    maxk = players[j].getType(i);
                } else if (players[j].getType(i) > maxq && players[j].getType(i) != maxk)
                    maxq = players[j].getType(i);
            }

            for (j = 0; j < playersNumber; j++) {
                if (players[j].getType(i) == maxk) {
                    players[j].modifyPurse(bonusk[i], true);
                } else if (players[j].getType(i) == maxq)
                    players[j].modifyPurse(bonusq[i], true);
            }
        }

        Player aux;
        for (i = 0; i < playersNumber - 1; i++) {
            for (j = i; j < playersNumber; j++)
                if (players[i].finalScore() < players[j].finalScore()) {
                    aux = players[i];
                    players[i] = players[j];
                    players[j] = aux;
                }
        }

        for (i = 0; i < playersNumber; i++) {
            System.out.println(players[i].getStrategy() + ": " + players[i].finalScore());
        }
    }

}