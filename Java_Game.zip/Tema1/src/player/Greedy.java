package player;

import goods.Goods;

public class Greedy extends Player {

	public Greedy() {
		this.strategy = "GREEDY";
		this.goods = new Goods[6];
		this.purse = 50;
		this.parity = 0;
	}

	public void createSack() {

		boolean onlyIlegal = true, hasIlegal = false;
		int i, max = -1, max1 = -1, id = -1, id1 = -1, j = -1;
		int v[] = new int[4];

		for (i = 0; i < 6; i++) {
			if (this.goods[i].getLegal() == true) {
				onlyIlegal = false;
				v[this.goods[i].getId()]++;
			} else
				hasIlegal = true;
			if (this.goods[i].getProfit() > max1) {
				id1 = i;
				max1 = this.goods[i].getProfit();
			}
		}

		if (onlyIlegal == true) {
			this.sack = new Sack(1, 0);
			this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[id1].getId()));;
			this.goods[id1].removeId();
		} else {
			max = 0;
			for (i = 0; i < 4; i++) {
				if (v[i] >= max) {
					max = v[i];
					id = i;
				}
			}

			if (max == 6)
				max--;
			else if (max < 5 && this.parity % 2 == 0 && hasIlegal == true) {
				max++;
				this.sack = new Sack(max, id);
				j++;
				this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[id1].getId()));;
				this.goods[id1].removeId();
			} else
				this.sack = new Sack(max, id);

			for (i = 0; i < 6 && j < 4; i++) {
				if (this.goods[i].getId() == id) {
					j++;
					this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[i].getId()));;
					this.goods[i].removeId();
				}
			}
		}

	}

	public void checkSack(Player player) {

		if (player.getSackBribe() > 0) {
			this.modifyPurse(player.getSackBribe(), true);
			player.modifyPurse(player.getSackBribe(), false);
			return;
		}

		super.checkSack(player);

	}
}