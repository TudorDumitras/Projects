package player;

import goods.Goods;

public class Basic extends Player {

	public Basic() {
		this.strategy = "BASIC";
		this.goods = new Goods[6];
		this.purse = 50;
	}

	public void createSack() {
		super.createSack();
	}

	public void checkSack(Player player) {
		super.checkSack(player);
	}
}