package player;

import goods.Goods;

public class Wizzard extends Player {

    public Wizzard() {
        this.strategy = "WIZARD";
        this.goods = new Goods[6];
        this.purse = 50;
    }

    public void createSack() {
        boolean onlyIlegal = true;
        int i, max = -1, id = -1, j = -1;
        int v[] = new int[4];

        for (i = 0; i < 6; i++) {
            if (this.goods[i].getLegal()) {
                onlyIlegal = false;
                v[this.goods[i].getId()]++;
            }
            if (this.goods[i].getProfit() > max) {
                id = i;
                max = this.goods[i].getProfit();
            }
        }

        if (onlyIlegal) {
            this.sack = new Sack(0, 0);
        } else {
            max = 0;
            for (i = 0; i < 4; i++) {
                if (v[i] >= max) {
                    max = v[i];
                    id = i;
                }
            }

            if (max == 6)
                max--;
            this.sack = new Sack(max, id);

            for (i = 0; i < 6 && j < 4; i++) {
                if (this.goods[i].getId() == id) {
                    j++;
                    this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[i].getId()));
                    this.goods[i].removeId();
                }
            }
        }
    }

    public void checkSack(Player player) {
        if (player.getSackBribe() > 0)
            super.checkSack(player);
    }
}