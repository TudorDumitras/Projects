package player;

import main.GameMechanics;
import goods.*;

public class Player {
	protected String strategy;
	protected int purse;
	protected Goods[] goods;
	protected Sack sack;
	protected int parity;
	protected int[] totalType = {
			0,
			0,
			0,
			0
	};
	protected int value = 0;

	GameMechanics mechanics = new GameMechanics();

	public String getStrategy() {
		return this.strategy;
	}

	public void modifyPurse(int value, boolean add) {
		if (add == true)
			this.purse += value;
		else
			this.purse -= value;
	}

	public int getParity() {
		return this.parity;
	}

	public void increaseParity() {
		this.parity++;
	}

	public void addValue(int ammount) {
		this.value += ammount;
	}

	public void addCard(int i, Goods good) {
		this.goods[i] = good;
	}

	public int getType(int i) {
		return this.totalType[i];
	}

	public int finalScore() {
		return (this.purse + this.value);
	}

	public int getSackElements() {
		return this.sack.getElements();
	}

	public int getSackGoodId(int i) {
		return this.sack.getGoodsId(i);
	}

	public int getSackId() {
		return this.sack.getDeclaredGoodId();
	}

	public int getGoodPenalty(int i) {
		return this.sack.getGoodsPenalty(i);
	}

	public Goods getSackGood(int i) {
		return this.sack.getGoodsInSack(i);
	}

	public void newSack(Sack aux) {
		this.sack = aux;
	}

	public int getSackBribe() {
		return this.sack.getBribe();
	}

	public int getGoodId(int i) {
		return this.goods[i].getId();
	}

	public Player() {

	}
	public void createSack() {
		boolean onlyIlegal = true;
		int i, max = -1, id = -1, j = -1;
		int v[] = new int[4];

		for (i = 0; i < 6; i++) {
			if (this.goods[i].getLegal()) {
				onlyIlegal = false;
				v[this.goods[i].getId()]++;
			}
			if (this.goods[i].getProfit() > max) {
				id = i;
				max = this.goods[i].getProfit();
			}
		}

		if (onlyIlegal) {
			this.sack = new Sack(1, 0);
			this.sack.addGoodsInSack(0, mechanics.newGood(this.goods[id].getId()));
			this.goods[id].removeId();
		} else {
			max = 0;
			for (i = 0; i < 4; i++) {
				if (v[i] >= max) {
					max = v[i];
					id = i;
				}
			}

			if (max == 6)
				max--;
			this.sack = new Sack(max, id);

			for (i = 0; i < 6 && j < 4; i++) {
				if (this.goods[i].getId() == id) {
					j++;
					this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[i].getId()));
					this.goods[i].removeId();
				}
			}
		}

	}

	public void checkSack(Player player) {
		int n, i, m, j;
		boolean honest = true;
		n = player.getSackElements();
		m = 0;

		for (i = 0; i < n; i++)
			if (player.getSackGoodId(i) != player.getSackId())
				honest = false;
			else
				m++;

		if (honest) {
			this.modifyPurse(player.getSackElements() * player.getGoodPenalty(0), false);
			player.modifyPurse(player.getSackElements() * player.getGoodPenalty(0), true);
		} else {
			Sack aux = new Sack(m, player.getSackId());
			j = -1;
			for (i = 0; i < n; i++) {
				if (player.getSackGoodId(i) != player.getSackId()) {
					this.modifyPurse(player.getGoodPenalty(i), true);
					player.modifyPurse(player.getGoodPenalty(i), false);
				} else {
					j++;
					aux.addGoodsInSack(j, player.getSackGood(i));
				}
			}
			player.newSack(aux);
		}

	}

	public void sellGoods() {
		int i, n;
		n = this.sack.getElements();

		for (i = 0; i < n; i++) {
			this.value += this.sack.getGoodsProfit(i);
			this.value += this.sack.getGoodsBonus(i);
			if (this.sack.getGoodLegal(i))
				this.totalType[this.sack.getGoodsId(i)]++;
			else {
				this.totalType[this.sack.getGoodsBonusId(i)]++;
				this.totalType[this.sack.getGoodsBonusId(i)]++;
				if (this.sack.getGoodsBonusId(i) == 1)
					this.totalType[this.sack.getGoodsBonusId(i)]++;
			}
		}
	}

}