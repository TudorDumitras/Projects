package player;

import goods.*;

public class Sack {
	private int elements;
	private int bribe;
	private int declaredGoodId;
	private Goods[] goodsInSack;

	Sack(int n, int id) {
		this.elements = n;
		this.goodsInSack = new Goods[n];
		this.declaredGoodId = id;
		this.bribe = 0;
	}

	Sack(int n, int id, int b) {
		this.elements = n;
		this.goodsInSack = new Goods[n];
		this.bribe = b;
		this.declaredGoodId = id;
	}

	public void addGoodsInSack(int i, Goods good) {
		this.goodsInSack[i] = good;
	}

	public int getGoodsId(int i) {
		return this.goodsInSack[i].getId();
	}

	public int getDeclaredGoodId() {
		return this.declaredGoodId;
	}

	public int getElements() {
		return this.elements;
	}

	public Goods getGoodsInSack(int i) {
		return this.goodsInSack[i];
	}

	public int getGoodsPenalty(int i) {
		return this.goodsInSack[i].getPenalty();
	}

	public int getGoodsProfit(int i) {
		return this.goodsInSack[i].getProfit();
	}

	public boolean getGoodLegal(int i) {
		return this.goodsInSack[i].getLegal();
	}

	public int getGoodsBonus(int i) {
		return this.goodsInSack[i].getBonus();
	}

	public int getGoodsBonusId(int i) {
		return this.goodsInSack[i].getBonusId();
	}

	public int getBribe() {
		return this.bribe;
	}
}