package player;

import goods.Goods;

public class Bribe extends Player {

	public Bribe() {
		this.strategy = "BRIBED";
		this.goods = new Goods[6];
		this.purse = 50;
	}

	public void createSack() {

		boolean onlyIlegal = true, hasIlegal = false;
		int i, max = -1, id = -1, j = -1, n = 0, m = 0, min = 20, max1 = -1, id1 = -1;
		int v[] = new int[4];

		for (i = 0; i < 6; i++) {
			if (this.goods[i].getLegal() == true) {
				onlyIlegal = false;
				v[this.goods[i].getId()]++;
			} else {
				hasIlegal = true;
				n++;
				if (this.goods[i].getProfit() > max) {
					max1 = max;
					id1 = id;
					max = this.goods[i].getProfit();
					id = this.goods[i].getId();
				} else if (this.goods[i].getProfit() > max1) {
					max1 = this.goods[i].getProfit();
					id1 = this.goods[i].getId();
				}
			}
			if (this.goods[i].getProfit() < min) {
				min = this.goods[i].getProfit();
				m++;
			}
		}

		if (onlyIlegal == true && this.purse >= 10) {
			this.sack = new Sack(5, 0, 10);

			for (i = 0; i < 6; i++) {
				if (m != 1) {
					j++;
					this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[i].getId()));
					this.goods[i].removeId();
					if (this.goods[i].getProfit() == min) {
						m--;
					}
				} else {
					if (this.goods[i].getProfit() != min) {
						j++;
						this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[i].getId()));
						this.goods[i].removeId();
					}
				}
			}
		} else if (onlyIlegal == true && this.purse >= 5) {
			this.sack = new Sack(2, 0, 5);
			j++;
			this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[id].getId()));
			this.goods[id].removeId();
			j++;
			this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[id1].getId()));
			this.goods[id1].removeId();

		} else if (this.purse < 5 || hasIlegal == false) {
			super.createSack();
		} else {

			if (n > 2 && this.purse >= 10) {
				this.sack = new Sack(n, 0, 10);

				for (i = 0; i < 6 && j < 4; i++) {
					if (this.goods[i].getLegal() == false) {
						j++;
						this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[i].getId()));;
						this.goods[i].removeId();
					}
				}

			} else if (n > 2 && this.purse >= 5) {
				this.sack = new Sack(2, 0, 5);

				j++;
				this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[id].getId()));;
				this.goods[id].removeId();
				j++;
				this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[id1].getId()));;
				this.goods[id1].removeId();

			} else {
				this.sack = new Sack(n, 0, 5);

				for (i = 0; i < 6 && j < 4; i++) {
					if (this.goods[i].getLegal() == false) {
						j++;
						this.sack.addGoodsInSack(j, mechanics.newGood(this.goods[i].getId()));;
						this.goods[i].removeId();
					}
				}
			}
		}

	}

	public void checkSack(Player player) {
		super.checkSack(player);

	}

}