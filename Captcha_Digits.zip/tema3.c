#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "bmp_header.h"

#define N 100

const int dx[4] = {0, 0, 1, -1};
const int dy[4] = {1, -1, 0, 0};

struct pixel {
    unsigned char R, G, B;
};

struct bmp_image {
    struct bmp_fileheader fh;
    struct bmp_infoheader ih;
    struct pixel bit_map[100][100];
};

void Read_Pixel(FILE *in, struct pixel *p) {
    fread(&p->B, sizeof(char), 1, in);
    fread(&p->G, sizeof(char), 1, in);
    fread(&p->R, sizeof(char), 1, in);
}

void Read_Image(FILE *in, struct bmp_image *im) {
    fread(&im->fh.fileMarker1, sizeof(char), 1, in);
	fread(&im->fh.fileMarker2, sizeof(char), 1, in);
	fread(&im->fh.bfSize, sizeof(int), 1, in);
	fread(&im->fh.unused1, sizeof(short), 1, in);
	fread(&im->fh.unused1, sizeof(short), 1, in);
	fread(&im->fh.imageDataOffset, sizeof(int), 1, in);
	fread(&im->ih.biSize, sizeof(int), 1, in);
	fread(&im->ih.width, sizeof(int), 1, in);
	fread(&im->ih.height, sizeof(int), 1, in);
	fread(&im->ih.planes, sizeof(short), 1, in);
	fread(&im->ih.bitPix, sizeof(short), 1, in);
	fread(&im->ih.biCompression, sizeof(int), 1, in);
	fread(&im->ih.biSizeImage, sizeof(int), 1, in);
	fread(&im->ih.biXPelsPerMeter, sizeof(int), 1, in);
	fread(&im->ih.biYPelsPerMeter, sizeof(int), 1, in);
	fread(&im->ih.biClrUsed, sizeof(int), 1, in);
	fread(&im->ih.biClrImportant, sizeof(int), 1, in);


    int i, j;
    for(i = im->ih.height - 1; i >= 0; i--) {
        for(j = 0; j < im->ih.width; j++) {
            Read_Pixel(in, &im->bit_map[i][j]); //citesc linia pixel cu pixel
        }
        if(im->ih.width * 3 % 4) { //daca e nevoie de padding
            fseek(in, 4 - (im->ih.width * 3 % 4), SEEK_CUR); //avanses cursorul cate pozitii este nevoie ca sa trec peste padding
        }
    }
}

void Print_Pixel(FILE *out, struct pixel p) {
    fwrite(&p.B, sizeof(char), 1, out);
    fwrite(&p.G, sizeof(char), 1, out);
    fwrite(&p.R, sizeof(char), 1, out);
}

void Print_Image(FILE *out, struct bmp_image im) {
    fwrite(&im.fh.fileMarker1, sizeof(char), 1, out);
	fwrite(&im.fh.fileMarker2, sizeof(char), 1, out);
	fwrite(&im.fh.bfSize, sizeof(int), 1, out);
	fwrite(&im.fh.unused1, sizeof(short), 1, out);
	fwrite(&im.fh.unused1, sizeof(short), 1, out);
	fwrite(&im.fh.imageDataOffset, sizeof(int), 1, out);
	fwrite(&im.ih.biSize, sizeof(int), 1, out);
	fwrite(&im.ih.width, sizeof(int), 1, out);
	fwrite(&im.ih.height, sizeof(int), 1, out);
	fwrite(&im.ih.planes, sizeof(short), 1, out);
	fwrite(&im.ih.bitPix, sizeof(short), 1, out);
	fwrite(&im.ih.biCompression, sizeof(int), 1, out);
	fwrite(&im.ih.biSizeImage, sizeof(int), 1, out);
	fwrite(&im.ih.biXPelsPerMeter, sizeof(int), 1, out);
	fwrite(&im.ih.biYPelsPerMeter, sizeof(int), 1, out);
	fwrite(&im.ih.biClrUsed, sizeof(int), 1, out);
	fwrite(&im.ih.biClrImportant, sizeof(int), 1, out);
   

    int zero = 0; // 4 octeti egali cu 0, pentru padding
    int i, j;
    for(i = im.ih.height - 1; i >= 0; i--) {
        for(j = 0; j < im.ih.width; j++) {
            Print_Pixel(out, im.bit_map[i][j]); //afisez linia pixel cu pixel
        }
        if(im.ih.width * 3 % 4) { //daca e nevoie de padding
            fwrite(&zero, sizeof(char), 4 - (im.ih.width * 3 % 4), out); //afisez cati octeti nuli este nevoie ca sa trec peste padding
        }
    }
}


void Change_Color(char *img_name, struct pixel new_color)
{
    char in_name[30];
    strcpy(in_name, img_name);
    strcat(in_name, ".bmp");

    FILE *in = fopen(in_name, "rb");
	
    if (in == NULL) {
        fprintf(stderr, "ERROR: Can't open file %s", img_name);
    }
	
	char out_name[30];
    strcpy(out_name, img_name);
    strcat(out_name, "_task1.bmp");
	
	FILE *out = fopen(out_name, "wb");
	if (out == NULL) {
        fprintf(stderr, "ERROR: Can't open file out");
    }

    struct bmp_image im;
    Read_Image(in, &im);
   
    int i, j;
    for(i = 0; i < im.ih.height; i++) {
        for(j = 0; j < im.ih.width; j++) {
            if(!(im.bit_map[i][j].R == 255 && im.bit_map[i][j].G == 255 && im.bit_map[i][j].B == 255)) {
                im.bit_map[i][j].R = new_color.R;
                im.bit_map[i][j].G = new_color.G;
                im.bit_map[i][j].B = new_color.B;
            }
        }
    }
    Print_Image(out, im);
    

    fclose(in);
	fclose(out);
}

struct pair {
    int fi, se;
};

void Fill(int i, int j, int *count, struct pair v[20], struct bmp_image *im) {
    v[++(*count)].fi = i;
    v[*count].se = j;
    
    im->bit_map[i][j].R = im->bit_map[i][j].G = im->bit_map[i][j].B = 255;
    
    int d, ni, nj;
    for(d = 0; d < 4; d++) {
        ni = i + dx[d]; //noul i
        nj = j + dy[d]; //noul j
        if(ni >= 0 && ni < im->ih.height && nj >= 0 && nj < im->ih.width) { //daca noua pozitie se afla in imagine
           if(!(im->bit_map[ni][nj].R == 255 && im->bit_map[ni][nj].R == 255 && im->bit_map[ni][nj].R == 255)) {
               Fill(ni, nj, count, v, im);
           }
        }
    }
}

int Identify_Digit(int count, struct pair v[20]) {
    int i;
    for(i = count; i >= 1; i--) { //normalizez pozitiile pixelilor colorati in cadrul unei cifre
        v[i].fi -= v[1].fi; 
        v[i].se -= v[1].se;
    }


    //diferentiez intre cifre in functie de numarul pixelilor colorati ce apar in imaginea acesteia
    if (count == 16) {
        return 0;
    }
    else if (count == 5) {
        return 1;
    }
    else if (count == 11) {
        return 4;
    }
    else if (count == 9) {
        return 7;
    }
    else if(count == 19) {
        return 8;
    }
    else if(count == 18) {
        for(i = 1; i <= count; i++) {
            if(v[i].fi == 3 && v[i].se == 0) { // diferentiez intre 6 si 9
                return 6;
            }
        }
        return 9;
    }
    else if(count == 17) { // 2 3 sau 5
        for(i = 1; i <= count; i++) {
            if(v[i].fi == 3 && v[i].se == 0) {
                return 2;
            }
            if(v[i].fi == 1 && v[i].se == 0) {
                return 5;
            }
        }
        return 3;
    }
    else {
        return -2;
    }
}

struct digit {
    int d;
    struct pixel color;
    struct pair pos; 
};

int cmp (const void * a, const void * b) {
    return ((struct digit*)a)->pos.se - ((struct digit*)b)->pos.se;
}

void Extract_Digits(struct bmp_image *im, int *num_digits, struct digit digits[100]) {
    int count;
    struct pair v[20];

    int i, j;
    for(j = 0; j < im->ih.width; j++) {
        for(i = 0; i < im->ih.height; i++) {
            if(!(im->bit_map[i][j].R == 255 && im->bit_map[i][j].G == 255 && im->bit_map[i][j].B == 255)) { // daca ajungem pe un pixel colorat
                count = 0;
                memset(v, 0, sizeof(v));

                digits[*num_digits].color.R = im->bit_map[i][j].R;
                digits[*num_digits].color.G = im->bit_map[i][j].G;
                digits[*num_digits].color.B = im->bit_map[i][j].B;

                Fill(i, j, &count, v, im); // numaram cati pixeli colorati sunt conexi (formeaza cifra)
                digits[*num_digits].d = Identify_Digit(count, v); //gesim cifra
                
                digits[*num_digits].pos.fi = i;
                digits[*num_digits].pos.se = j;
                if(digits[*num_digits].d == 1) {
                    digits[*num_digits].pos.se -= 4; // daca cifra este 1, coltul de inceput al cifrei este coltul de inceput al chenarului de 5x5
                }

                (*num_digits)++;
            }
        }
    } 

    qsort(digits, *num_digits, sizeof(struct digit), cmp); //sortez cifrele dupa indicele coloanei pe care apar
}

void Get_Captcha(char *img_name) {
    char in_name[30];
    strcpy(in_name, img_name);
    strcat(in_name, ".bmp");

    FILE *in = fopen(in_name, "rb");
	
    if (in == NULL) {
        fprintf(stderr, "ERROR: Can't open file %s", in_name);
    }
	
	char out_name[30];
    strcpy(out_name, img_name);
    strcat(out_name, "_task2.txt");
	
	FILE *out = fopen(out_name, "w");
	if (out == NULL) {
        fprintf(stderr, "ERROR: Can't open file %s", out_name);
    }
    
    struct bmp_image im;
    Read_Image(in, &im);

    struct digit digits[100];
    int num_digits = 0;
    
    Extract_Digits(&im, &num_digits, digits);

    int i;
    for(i = 0; i < num_digits; i++) {
        fprintf(out, "%d", digits[i].d);
    }

    fclose(in);
    fclose(out);
}

void Assign_Color(struct pixel *a, struct pixel *b) {
    a->R = b->R;
    a->G = b->G;
    a->B = b->B;
}

void Add_Digit(struct bmp_image *im, struct digit *dig) {
    int i;
    if(dig->d == 0) {
        for(i = 0; i < 5; i++) {
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 4][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se + 4], &dig->color);
        }
    }
    else if(dig->d == 1) {
        for(i = 0; i < 5; i++) {
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se + 4], &dig->color);
        }

    }
    else if(dig->d == 2) {
        for(i = 0; i < 5; i++) {
            Assign_Color(&im->bit_map[dig->pos.fi][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 2][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 4][dig->pos.se + i], &dig->color);
        }
        
        Assign_Color(&im->bit_map[dig->pos.fi + 1][dig->pos.se + 4], &dig->color);
        Assign_Color(&im->bit_map[dig->pos.fi + 3][dig->pos.se], &dig->color);
    }
    else if(dig->d == 3) {
        for(i = 0; i < 5; i++) {
            Assign_Color(&im->bit_map[dig->pos.fi][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 2][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 4][dig->pos.se + i], &dig->color);
        }
        
        Assign_Color(&im->bit_map[dig->pos.fi + 1][dig->pos.se + 4], &dig->color);
        Assign_Color(&im->bit_map[dig->pos.fi + 3][dig->pos.se + 4], &dig->color);


    }
    else if(dig->d == 4) {
        for(i = 0; i < 5; i++) {
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se + 4], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 2][dig->pos.se + i], &dig->color);
        }
        
        Assign_Color(&im->bit_map[dig->pos.fi][dig->pos.se], &dig->color);
        Assign_Color(&im->bit_map[dig->pos.fi + 1][dig->pos.se], &dig->color);

    }
    else if(dig->d == 5) {
        for(i = 0; i < 5; i++) {
            Assign_Color(&im->bit_map[dig->pos.fi][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 2][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 4][dig->pos.se + i], &dig->color);
        }
        
        Assign_Color(&im->bit_map[dig->pos.fi + 1][dig->pos.se], &dig->color);
        Assign_Color(&im->bit_map[dig->pos.fi + 3][dig->pos.se + 4], &dig->color);


    }
    else if(dig->d == 6) {
        for(i = 0; i < 5; i++) {
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 4][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se + 4], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 2][dig->pos.se + i], &dig->color);
        }

        Assign_Color(&im->bit_map[dig->pos.fi + 1][dig->pos.se + 4], &im->bit_map[dig->pos.fi + 1][dig->pos.se + 3]);
    }
    else if(dig->d == 7) {
        for(i = 0; i < 5; i++) {
            Assign_Color(&im->bit_map[dig->pos.fi][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se + 4], &dig->color);
        }


    }
    else if(dig->d == 8) {
        for(i = 0; i < 5; i++) {
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 4][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se + 4], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 2][dig->pos.se + i], &dig->color);
        }

    }
    else {
        for(i = 0; i < 5; i++) {
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 4][dig->pos.se + i], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + i][dig->pos.se + 4], &dig->color);
            Assign_Color(&im->bit_map[dig->pos.fi + 2][dig->pos.se + i], &dig->color);
        }
        Assign_Color(&im->bit_map[dig->pos.fi + 3][dig->pos.se], &im->bit_map[dig->pos.fi + 1][dig->pos.se + 3]);
    }
}

void Remove_Digits(char *img_name, char forb[10]) {
    char in_name[30];
    strcpy(in_name, img_name);
    strcat(in_name, ".bmp");

    FILE *in = fopen(in_name, "rb");
	
    if (in == NULL) {
        fprintf(stderr, "ERROR: Can't open file %s", in_name);
    }
	
	char out_name[30];
    strcpy(out_name, img_name);
    strcat(out_name, "_task3.bmp");
	
	FILE *out = fopen(out_name, "wb");
	if (out == NULL) {
        fprintf(stderr, "ERROR: Can't open file %s", out_name);
    }
    
    struct bmp_image im;
    Read_Image(in, &im);

    struct digit digits[100];
    int num_digits = 0;
    
    Extract_Digits(&im, &num_digits, digits);

   // printf("\n\n");
    int i, j = 0;
    for(i = 0; i < num_digits; i++) {
     //   printf("%d %d\n", digits[i].d, digits[i].pos.se);
        if(!forb[digits[i].d]) { //daca trebuie sa pastrez a i-a cifra
            digits[j].d = digits[i].d; //mut a i-a cifra pe prima pozitie libera
        
            digits[j].color.R = digits[i].color.R;
            digits[j].color.G = digits[i].color.G;
            digits[j].color.B = digits[i].color.B;
            
            j++;
        }
    }
   // printf("\n");
    num_digits = j;
    for(i = 0; i < num_digits; i++) {
       // printf("%d %d\n", digits[i].d, digits[i].pos.se);
        Add_Digit(&im, &digits[i]);
    }

    Print_Image(out, im);
    
    fclose(in);
    fclose(out);
}

int main()
{
	// numele fisierului de intrare
    char fn[] = "input.txt";
 
    // deschidere fisier de intrare pentru citire in mod text
    FILE *in = fopen(fn, "r");
 
    // verific daca fisierul a fost deschis cu succes
    if (in == NULL) {
        fprintf(stderr, "ERROR: Can't open file %s", fn);
        return -1;
    }

    //declar numele imaginii si variabila pentru noua culoare BGR
	char img_name[30];
    struct pixel default_color;
    int r, b, g;
    fscanf(in, "%s%d%d%d", img_name, &b, &g, &r); //citesc numele fisierului si noua culoare BGR

    default_color.R = r;
    default_color.B = b;
    default_color.G = g;
    

    img_name[strlen(img_name) - 4] = '\x0'; //elimin extensia .bmp

    char forbidden_digits[20];
    fgets(forbidden_digits, 20, in);
    fgets(forbidden_digits, 20, in);
   
    int i, len = strlen(forbidden_digits);
    char forb[10]; //vector de frecventa pentru cifrele care trebuie sterse
    memset(forb, 0, sizeof(forb));

    for(i = 0; i < len; i++) {
        if(forbidden_digits[i] >= '0' && forbidden_digits[i] <= '9') {
            forb[forbidden_digits[i] - '0'] = 1;
        }
    }

	fclose(in);

	Change_Color(img_name, default_color);
    Get_Captcha(img_name);
    Remove_Digits(img_name, forb);

	return 0;
}

