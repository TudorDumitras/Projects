% Dumitras, Tudor-Ionut, 313CD

function B = GramSchmidt(A)
  
  %Folosesc GramSchmidt pentru a calcula Q si R
  
	[m n]=size(A);
	Q = A;
	R = zeros(m,n);
	for k = 1:n
		R(k,k) = norm(Q(1:m,k));
		Q(1:m,k) = Q(1:m,k) / R(k,k);
	   for j = k+1:n
		R(k,j) = Q(1:m,k)' * Q(1:m,j);
		Q(1:m,j) = Q(1:m,j) - Q(1:m,k) * R(k,j);
	   endfor
	endfor

  Q = Q';
  
  %Rezolv sistemul de ecuatii pentru determinarea inversei
  
  for i = 1:n
    B(n,i) = Q(n,i)/R(n,n);
    for j = (n-1):-1:1
      s = 0;
      for k = j:(n-1)
        s = s + R(j,k+1)*B(k+1,i);
      endfor
      B(j,i) = (Q(j,i)-s)/R(j,j);
    endfor
  endfor
  
	% Functia care calculeaza inversa matricii A folosind factorizari Gram-Schmidt
	% Se va inlocui aceasta linie cu descrierea algoritmului de inversare
endfunction