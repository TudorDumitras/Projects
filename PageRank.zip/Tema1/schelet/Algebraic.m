% Dumitras, Tudor-Ionut, 313CD

function R = Algebraic(nume, d)

  %Deschid file-ul de intrare si citesc valorile

  f = fopen(nume);
  nods = fscanf(f, "%d", 1);
  M = zeros(nods);
  A = zeros(nods);
  K = ones(nods, 1);
  I = eye(nods);
  
  for i = 1:nods
      in(i) = fscanf(f, "%d", 1);
      ne(i) = fscanf(f, "%d", 1);
      no(i) = ne(i);
      for j = 1:ne(i);
        A(i,j) = fscanf(f, "%d", 1);
        if A(i,j) == i
          A(i,j) = 0;
          no(i) = no(i)-1;
        endif
      endfor
  endfor
  
  for i = 1:nods
    for j = 1:nods
      if i!=j
        for k = 1:nods
          if j == A(i,k)
            B(i,j) = 1;
          endif
        endfor
      endif
    endfor
  endfor
  A = B;
  
  for i = 1:nods
    x = 0;
    for j = 1:nods
      if A(i,j) != 0
        x = j;
        M(i,x) = 1/no(i);
      endif
     endfor
   endfor
  
  %Folosesc GramSchmidt pentru a determina inversa si a calcula PageRank-ul
  
  D = (I - d*M');
  T = GramSchmidt(D);
  P = (1-d)/nods*K;
  R = T*P;
  
  val1 = fscanf(f, "%f", 1);
  val2 = fscanf(f, "%f", 1);
  
  fclose(nume);
  
	% Functia care calculeaza vectorul PageRank folosind varianta algebrica de calcul.
	% Intrari: 
	%	-> nume: numele fisierului in care se scrie;
	%	-> d: probabilitatea ca un anumit utilizator sa continue navigarea la o pagina urmatoare.
	% Iesiri:
	%	-> R: vectorul de PageRank-uri acordat pentru fiecare pagina.
  endfunction
