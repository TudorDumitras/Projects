% Dumitras, Tudor-Ionut, 313CD

function [R val1 val2 nods] = Iterative(nume, d, eps)

  %Deschid file-ul de intrare si citesc valorile
  
  f = fopen(nume);
  nods = fscanf(f, "%d", 1);
  B = zeros(nods);
  A = zeros(nods);
  
  for i = 1:nods
      in(i) = fscanf(f, "%d", 1);
      ne(i) = fscanf(f, "%d", 1);
      no(i) = ne(i);
      for j = 1:ne(i);
        A(i,j) = fscanf(f, "%d", 1);
        if A(i,j) == i
          A(i,j) = 0;
          no(i) = no(i)-1;
        endif
      endfor
  endfor
  
  val1 = fscanf(f, "%f", 1);
  val2 = fscanf(f, "%f", 1);
  
  %Creez Matricea de adiacenta
  
  for i = 1:nods
    for j = 1:nods
      if i!=j
        for k = 1:nods
          if j == A(i,k)
            B(i,j) = 1;
          endif
        endfor
      endif
    endfor
  endfor
  A = B;
  
  %Folosesc metoda recursiva, calculez fiecare PageRank
  %Adaug noile PageRank-uri in noul R
  
  for i = 1:nods
   Pra(i) = 1/nods;
   Ra(i) = Pra(i);
  endfor
  
  for i = 1:nods
    s = 0;
    for j = 1:nods
      if A(j,i)==1
         s = s + Pra(j)/no(j);
      endif
    endfor
    Pr(i) = s*d + (1-d)/nods;
    R(i) = Pr(i);
  endfor
  
  for i = 1:nods
   Pra(i) = Pr(i);
  endfor
  
  do
    for i = 1:nods
     s = 0;
     for j = 1:nods
      if A(j,i)==1
         s = s + Pra(j)/no(j);
      endif
     endfor
     Pr(i) = s*d + (1-d)/nods;
    endfor
    
    for i = 1:nods
     Pra(i) = Pr(i);
     Ra(i) = R(i);
     R(i) = Pr(i);
    endfor
  until abs(R - Ra)<eps
  
  
  R = Ra';
  
  fclose(nume);
  
endfunction