Dumitras, Tudor-Ionut, 313CD

Tema 1 MN - PageRank

Pentru algoritmul Iterative am folosit metoda recursiva, calculez fiecare PageRank dupa o iteratie si il adaug in noul vector R

Pentru algoritmul Algebraic notez D = (I - d*M') creez matricile R superior tringhiulara si Q ortogonala in functie de D, astfel incat D = Q*R, dupa care rezolv sistemul de ecuatii R*D^(-1) = Q'. La final folosesc formula R=D*(1-d)/nods*K.

Pentru calcularea gradului de apartenenta imi scot a si b din sistemul:
a*val1 + b = 0
A*val2 + b = 1

Sortez descrescator R-ul rezultat din Algebraic si calculez gradul de apartenenta pentru fiecare PageRank(R(i))

Dupa toate de mai sus fac scrierea in fisier.
