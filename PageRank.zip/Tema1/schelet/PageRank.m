% Dumitras, Tudor-Ionut, 313CD

function [R1 R2] = PageRank(nume, d, eps)
	
  % Apelez cele 3 functii create
  
  [R1 val1 val2 nods] = Iterative(nume, d, eps);
  R2 = Algebraic(nume, d, eps);

  %Mai jos creez file-ul .out si scriu in el cum se cere in cerinta
  
  fo = fopen(strcat(nume, ".out"), "w");
  
  fprintf(fo, "%d\n", nods);
  
  for i = 1:nods
    fprintf(fo, "%f\n", R1(i));
  endfor
  
  fprintf(fo, "\n");
  
  for i = 1:nods
    fprintf(fo, "%f\n", R2(i));
    in(i) = i;
  endfor
  
  fprintf(fo, "\n");
  
  %Dupa ce am scirs vectorul R2 il sortam
  
  for i = 1:(nods-1)
    for j = i+1:nods
      if R2(i) <= R2(j)
        aux = R2(i);
        R2(i) = R2(j);
        R2(j) = aux;
        
        aux = in(i);
        in(i) = in(j);
        in(j) = aux;
      endif
    endfor
  endfor
  
  for i = 1:nods
    u(i) = Apartenenta(R2(i), val1, val2);
  endfor
  
  for i = 1:nods
    fprintf(fo, "%d %d %f\n", i, in(i), u(i));
  endfor
  
  %Inchid file-ul .out
  
  fclose(fo);
  
endfunction