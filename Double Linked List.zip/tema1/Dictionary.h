#ifndef TABLE_H
#define TABLE_H

#include <stdio.h>
#include <stdlib.h>

// List element for Dictionary lists.
typedef struct ListNode {
	struct ListNode *next;
	struct ListNode *prev;
	char *key;
	char *value;
	int frequency;
} ListNode;

// Dictionary structure that includes the lists of elements and their number.
typedef struct Dictionary {
	ListNode **lists;		// lists of elements.
	int N;					// number of lists.
} Dictionary;


// Initializes an empty Dictionary structure.
Dictionary* createDictionary(int N);

// Adds an element to the Dictionary structure.
void addElement(Dictionary *dictionary, char *key, char *value, int frequency);

// Removes an element from the Dictionary structure.
void removeElement(Dictionary *dictionary, char *key, char *value);

// Prints all the elements from all the lists of the Dictionary structure.
void printDictionary(FILE *f, Dictionary *dictionary);

// Gets all the elements with the specified key and increments the frequencies.
ListNode* get(Dictionary *dictionary, char *key);

// Prints all the elements with the specified value.
void printValue(FILE *f, Dictionary *dictionary , char *value);

// Prints all the elements with the specified frequency.
void printFrequency(FILE *f, Dictionary *dictionary , int frequency);

// Returns a list containing the elements with the specified value.
ListNode* unionValues(Dictionary *dictionary, char *value);

// Returns a list containing the elements with maximum frequency in each list.
ListNode* unionMaxFrequencies(Dictionary *dictionary);

// Returns a new Dictionary with reversed lists of the input structure.
Dictionary* reverseLists(Dictionary *dictionary);

// Prints a double-linked non-circular list.
void printList(FILE *f, ListNode *list);

// Frees all the memory allocated for the Dictionary.
void freeDictionary(Dictionary *dictionary);

// Frees all the memory allocated for a double-linked non-circular list.
void freeList(ListNode *list);

//------------------------------------------------------------------------------

int StringValue(char *s1, char *s2){

	int sv1=0, sv2=0, nc1, nc2, i;

	nc1 = strlen(s1);
 
	for(i=0; i<nc1; i++)
	{
		sv1 = sv1 + s1[i];
	}

	nc2 = strlen(s2);
 
	for(i=0; i<nc2; i++)
	{
		sv2 = sv2 + s2[i];
	}

	if(sv1 < sv2)
		return 1;
	else 
		if(sv1 == sv2)
			return 0;
		else
			return -1;
			
}

int CheckCopy(Dictionary *dictionary, int r, char *key, char *value, int frequency) {

	int pp1=0, pp2=1;
	ListNode *start = dictionary->lists[r];

	while(pp1==0 && pp2==1)
	{	
		if(dictionary->lists[r]->next == start)
			{
				pp1 = 1;
			}
			

		if(StringValue(dictionary->lists[r]->value, value)==0 && StringValue(dictionary->lists[r]->key, key)==0)
			{
				pp2 = 0;
				dictionary->lists[r]->frequency += frequency;
			}

		dictionary->lists[r] = dictionary->lists[r]->next;
	}

	dictionary->lists[r] = start;	

	return pp2;
}

void SortList(Dictionary *dictionary, int r) {

	int pp;
	ListNode *start = dictionary->lists[r];
	ListNode *temp = dictionary->lists[r]->next;
	ListNode *aux = (ListNode*)malloc(sizeof(ListNode));
	
	while(dictionary->lists[r]->next != start)
	{
		pp=0;
		while(pp==0)
		{
			if(temp->next == start)
			{
				pp = 1;
			}
			
			if (dictionary->lists[r]->frequency < temp->frequency)
			{
				aux->frequency = dictionary->lists[r]->frequency;
				dictionary->lists[r]->frequency = temp->frequency;
				temp->frequency = aux->frequency;
				aux->value = dictionary->lists[r]->value;
				dictionary->lists[r]->value = temp->value;
				temp->value = aux->value;
				aux->key = dictionary->lists[r]->key;
				dictionary->lists[r]->key = temp->key;
				temp->key = aux->key;
			}
			else if(dictionary->lists[r]->frequency == temp->frequency)
			{
				if(StringValue(dictionary->lists[r]->value, temp->value)==-1)
				{
					aux->frequency = dictionary->lists[r]->frequency;
					dictionary->lists[r]->frequency = temp->frequency;
					temp->frequency = aux->frequency;
					aux->value = dictionary->lists[r]->value;
					dictionary->lists[r]->value = temp->value;
					temp->value = aux->value;
					aux->key = dictionary->lists[r]->key;
					dictionary->lists[r]->key = temp->key;
					temp->key = aux->key;
				}
				else if (StringValue(dictionary->lists[r]->value, temp->value)==0)
				{
					if(StringValue(dictionary->lists[r]->key, temp->key)==-1)
					{
						aux->frequency = dictionary->lists[r]->frequency;
						dictionary->lists[r]->frequency = temp->frequency;
						temp->frequency = aux->frequency;
						aux->value = dictionary->lists[r]->value;
						dictionary->lists[r]->value = temp->value;
						temp->value = aux->value;
						aux->key = dictionary->lists[r]->key;
						dictionary->lists[r]->key = temp->key;
						temp->key = aux->key;
					}
				}
			}

			temp=temp->next;
		}

		dictionary->lists[r] = dictionary->lists[r]->next;
		temp = dictionary->lists[r]->next;
	}

	dictionary->lists[r] = dictionary->lists[r]->next;
	free(aux);
}

void rSortList(Dictionary *dictionary, int r) {

	int pp;
	ListNode *start = dictionary->lists[r];
	ListNode *temp = dictionary->lists[r]->next;
	ListNode *aux = (ListNode*)malloc(sizeof(ListNode));
	
	while(dictionary->lists[r]->next != start)
	{
		pp=0;
		while(pp==0)
		{
			if(temp->next == start)
			{
				pp = 1;
			}
			
			if (dictionary->lists[r]->frequency > temp->frequency)
			{
				aux->frequency = dictionary->lists[r]->frequency;
				dictionary->lists[r]->frequency = temp->frequency;
				temp->frequency = aux->frequency;
				aux->value = dictionary->lists[r]->value;
				dictionary->lists[r]->value = temp->value;
				temp->value = aux->value;
				aux->key = dictionary->lists[r]->key;
				dictionary->lists[r]->key = temp->key;
				temp->key = aux->key;
			}
			else if(dictionary->lists[r]->frequency == temp->frequency)
			{
				if(StringValue(dictionary->lists[r]->value, temp->value)==1)
				{
					aux->frequency = dictionary->lists[r]->frequency;
					dictionary->lists[r]->frequency = temp->frequency;
					temp->frequency = aux->frequency;
					aux->value = dictionary->lists[r]->value;
					dictionary->lists[r]->value = temp->value;
					temp->value = aux->value;
					aux->key = dictionary->lists[r]->key;
					dictionary->lists[r]->key = temp->key;
					temp->key = aux->key;
				}
				else if (StringValue(dictionary->lists[r]->value, temp->value)==0)
				{
					if(StringValue(dictionary->lists[r]->key, temp->key)==1)
					{
						aux->frequency = dictionary->lists[r]->frequency;
						dictionary->lists[r]->frequency = temp->frequency;
						temp->frequency = aux->frequency;
						aux->value = dictionary->lists[r]->value;
						dictionary->lists[r]->value = temp->value;
						temp->value = aux->value;
						aux->key = dictionary->lists[r]->key;
						dictionary->lists[r]->key = temp->key;
						temp->key = aux->key;
					}
				}
			}

			temp=temp->next;
		}

		dictionary->lists[r] = dictionary->lists[r]->next;
		temp = dictionary->lists[r]->next;
	}

	dictionary->lists[r] = dictionary->lists[r]->next;
	free(aux);
}

int ListSize(ListNode *temp) {

	int ls=0, pp=0;
	ListNode *start = temp;
		
	while(pp==0 && temp!=NULL)
	{
		if(temp->next == start)
		{
			pp = 1;
		}
		ls++;
		temp = temp->next;
	}
	return ls;

}

int ListId(Dictionary *dictionary, char *key) {

	int r=0, i, ds, nc;

	ds = dictionary->N;
	nc = strlen(key);
 
	for(i=0; i<nc; i++)
	{
		r = r + key[i];
	}

	r = r%ds;

	return r;

}

Dictionary* createDictionary(int N) {
	// TODO

	Dictionary *dictionary = (Dictionary*)malloc(sizeof(Dictionary));
	dictionary->lists = (ListNode**)calloc(N, sizeof(ListNode*));
	dictionary->N = N;

	return dictionary;
}

void addElement(Dictionary *dictionary, char *key, char *value, int frequency) {
	// TODO

	int r, ls, ds, i, sl=0;
	r = ListId(dictionary, key);
	ds = dictionary->N; 
	
	if(dictionary->lists[r]==NULL)
	{
		dictionary->lists[r] = (ListNode*)malloc(sizeof(ListNode));
		dictionary->lists[r]->key = malloc((strlen(key)+1)*sizeof(char));
		strcpy(dictionary->lists[r]->key, key);
		dictionary->lists[r]->value = malloc((strlen(value)+1)*sizeof(char));
		strcpy(dictionary->lists[r]->value, value);
		dictionary->lists[r]->frequency = frequency;
		dictionary->lists[r]->next = dictionary->lists[r];
		dictionary->lists[r]->prev = dictionary->lists[r];
	}
	else 
	{
		if(CheckCopy(dictionary, r, key, value, frequency))
		{
			if(dictionary->lists[r]->next == dictionary->lists[r])
			{
			
				ListNode *temp = (ListNode*)malloc(sizeof(ListNode));
				temp->key = malloc((strlen(key)+1)*sizeof(char));
				strcpy(temp->key, key);
				temp->value = malloc((strlen(value)+1)*sizeof(char));
				strcpy(temp->value, value);
				temp->frequency = frequency;
				temp->next = dictionary->lists[r];
				temp->prev = dictionary->lists[r];
				dictionary->lists[r]->next = temp;
				dictionary->lists[r]->prev = temp;
			
			}
			else
			{	
				ls = ListSize(dictionary->lists[r]);
				if(ls == ds)
				{
					dictionary->lists[r] = dictionary->lists[r]->prev;
					strcpy(dictionary->lists[r]->key, key);
					strcpy(dictionary->lists[r]->value, value);
					dictionary->lists[r]->frequency = frequency;
					dictionary->lists[r] = dictionary->lists[r]->next;
				}
				else
				{
					ListNode *temp = (ListNode*)malloc(sizeof(ListNode));
					temp->prev = dictionary->lists[r]->prev;
					temp->next = dictionary->lists[r]; 
					dictionary->lists[r]->prev = temp;
					dictionary->lists[r] = temp->prev;
					dictionary->lists[r]->next = temp;
					temp->key = malloc((strlen(key)+1)*sizeof(char));
					strcpy(temp->key, key);
					temp->value = malloc((strlen(value)+1)*sizeof(char));
					strcpy(temp->value, value);
					temp->frequency = frequency;
					dictionary->lists[r] = temp->next;
				}
			}
		}
	}

	SortList(dictionary, r);

    return;
}

void removeElement(Dictionary *dictionary, char *key, char *value) {
	// TODO
	
	int i=0, ds=dictionary->N;
	int pp, co;


	for(i=0; i<ds; i++)
	{
		if(dictionary->lists[i]!=NULL)
		{
			ListNode *start = dictionary->lists[i];
			pp = 0;
			co = 0;

			while(pp==0)
			{
				if(dictionary->lists[i]->next == start)
				{
					pp = 1;
				}

				if(dictionary->lists[i]->next == dictionary->lists[i])
				{
					co = 1;		
				}

				if(StringValue(dictionary->lists[i]->value, value)==0 && StringValue(dictionary->lists[i]->key, key)==0)
				{
					if(co==1)
					{
						dictionary->lists[i]->next = NULL;
						dictionary->lists[i]->prev = NULL;
						free(dictionary->lists[i]->key);
						free(dictionary->lists[i]->value);
						free(dictionary->lists[i]);
						dictionary->lists[i] = NULL;
					}
					else
					{
						if(dictionary->lists[i]==start)
						{
							start = dictionary->lists[i]->next;
						}
						
						ListNode *temp = dictionary->lists[i]->prev;

						temp->next = dictionary->lists[i]->next;
						temp = dictionary->lists[i]->next;
						temp->prev = dictionary->lists[i]->prev;
						temp = dictionary->lists[i];
						dictionary->lists[i] = dictionary->lists[i]->prev;
						free(temp->key);
						free(temp->value);
						free(temp);
					}
				}

				if(co!=1)
				{
					dictionary->lists[i] = dictionary->lists[i]->next;
				}
			}
		}	

	}

	return;
}

void printDictionary(FILE *f, Dictionary *dictionary) {
	// TODO

	int i=0, ds=dictionary->N;
	int pp;


	for(i=0; i<ds; i++)
	{
		fprintf(f, "List %d: ", i);
		ListNode *start = dictionary->lists[i];
		pp = 0;

		if(dictionary->lists[i]!=NULL)
		{
			while(pp==0)
			{
				if(dictionary->lists[i]->next == start)
				{
					pp = 1;
				}
			
				fprintf(f, "(%s, %s, %d) ", dictionary->lists[i]->key, dictionary->lists[i]->value, dictionary->lists[i]->frequency);
				dictionary->lists[i] = dictionary->lists[i]->next;
			}
		}

		fprintf(f, "\n");
	}
	
	return;
}

ListNode* get(Dictionary *dictionary, char *key) {
	// TODO

	int i, ds=dictionary->N, pp=0, j, ls;

	ListNode *list = (ListNode*)malloc(sizeof(ListNode));
	list->frequency = -1;
	ListNode *head = list;

	for(i=0; i<ds; i++)
	{
	
		ListNode *start = dictionary->lists[i];

		if(dictionary->lists[i]!=NULL)
		{
			ls = ListSize(dictionary->lists[i]);
			for(j=0; j<ls; j++)
			{
				if(StringValue(dictionary->lists[i]->key, key)==0)
				{
					if(list->frequency == -1)
					{
						list->key = malloc((strlen(key)+1)*sizeof(char));
						strcpy(list->key, key);
						list->value = malloc((strlen(dictionary->lists[i]->value)+1)*sizeof(char));
						strcpy(list->value, dictionary->lists[i]->value);
						list->frequency = dictionary->lists[i]->frequency;
						list->next = NULL;
						list->prev = NULL;
						dictionary->lists[i]->frequency++;
					}
					else
					{
						ListNode *temp = (ListNode*)malloc(sizeof(ListNode));
						temp->key = malloc((strlen(key)+1)*sizeof(char));
						strcpy(temp->key, key);
						temp->value = malloc((strlen(dictionary->lists[i]->value)+1)*sizeof(char));
						strcpy(temp->value, dictionary->lists[i]->value);
						temp->frequency = dictionary->lists[i]->frequency;
						temp->next = NULL;
						temp->prev = list;
						list->next = temp;
						list = list->next;
						dictionary->lists[i]->frequency++;
					}
				}

				dictionary->lists[i] = dictionary->lists[i]->next;				
			}
			SortList(dictionary, i);
		}
		
	}

	if(list->frequency != -1)
	{
		list = head;
		return list;
	}
	else
		return NULL;
}

void printValue(FILE *f, Dictionary *dictionary , char *value) {
	// TODO
	
	int i=0, ds=dictionary->N;
	int pp;

	for(i=0; i<ds; i++)
	{
		ListNode *start = dictionary->lists[i];
		pp = 0;
		if(dictionary->lists[i]!=NULL)
		{
			while(pp==0)
			{
				if(dictionary->lists[i]->next == start)
				{
					pp = 1;
				}

				if(StringValue(dictionary->lists[i]->value, value) == 0)
				{
				fprintf(f, "(%s, %s, %d) ", dictionary->lists[i]->key, dictionary->lists[i]->value, dictionary->lists[i]->frequency);
				}

				dictionary->lists[i] = dictionary->lists[i]->next;
			}
		}
	}

	fprintf(f, "\n");

	return;
}

void printFrequency(FILE *f, Dictionary *dictionary , int frequency) {
	// TODO
	
	int i=0, ds=dictionary->N;
	int pp;

	for(i=0; i<ds; i++)
	{
		ListNode *start = dictionary->lists[i];
		pp = 0;
		if(dictionary->lists[i]!=NULL)
		{
			while(pp==0)
			{
				if(dictionary->lists[i]->next == start)
				{
					pp = 1;
				}

				if(dictionary->lists[i]->frequency == frequency)
				{
				fprintf(f, "(%s, %s, %d) ", dictionary->lists[i]->key, dictionary->lists[i]->value, dictionary->lists[i]->frequency);
				}

				dictionary->lists[i] = dictionary->lists[i]->next;
			}
		}
	}

	fprintf(f, "\n");

	return;
}

ListNode* unionValues(Dictionary *dictionary, char *value) {
	// TODO

	int i, ds=dictionary->N, pp=0, ls, j;

	ListNode *list = (ListNode*)malloc(sizeof(ListNode));
	list->frequency = -1;
	ListNode *head;


	for(i=0; i<ds; i++)
	{
	
		ListNode *start = dictionary->lists[i];

		if(dictionary->lists[i]!=NULL)
		{
			ls = ListSize(dictionary->lists[i]);
			for(j=0; j<ls; j++)
			{
				if(StringValue(dictionary->lists[i]->value, value)==0)
				{
					if(list->frequency == -1)
					{
						head = list;
						list->key = malloc((strlen(dictionary->lists[i]->key)+1)*sizeof(char));
						strcpy(list->key, dictionary->lists[i]->key);
						list->value = malloc((strlen(value)+1)*sizeof(char));
						strcpy(list->value, value);
						list->frequency = dictionary->lists[i]->frequency;
						list->next = NULL;
						list->prev = NULL;
					}
					else
					{
						ListNode *temp = (ListNode*)malloc(sizeof(ListNode));
						temp->key = malloc((strlen(dictionary->lists[i]->key)+1)*sizeof(char));
						strcpy(temp->key, dictionary->lists[i]->key);
						temp->value = malloc((strlen(value)+1)*sizeof(char));
						strcpy(temp->value, value);
						temp->frequency = dictionary->lists[i]->frequency;
						temp->next = NULL;
						temp->prev = list;
						list->next = temp;
						list = list->next;
					}
				}

				dictionary->lists[i] = dictionary->lists[i]->next;				
			}
		}
	}

	if(list->frequency != -1)
	{
		list = head;
		return list;
	}
	else
		return NULL;
}

ListNode* unionMaxFrequencies(Dictionary *dictionary) {
	// TODO

	int i, ds=dictionary->N,pp;

	ListNode *list = (ListNode*)malloc(sizeof(ListNode));
	list->frequency = -1;
	ListNode *head;


	for(i=0; i<ds; i++)
	{
		pp=0;
		ListNode *start = dictionary->lists[i];

		if(dictionary->lists[i]!=NULL)
		{	
			while(pp==0)
			{
			if(list->frequency == -1)
			{
				head = list;
				list->key = malloc((strlen(dictionary->lists[i]->key)+1)*sizeof(char));
				strcpy(list->key, dictionary->lists[i]->key);
				list->value = malloc((strlen(dictionary->lists[i]->value)+1)*sizeof(char));
				strcpy(list->value, dictionary->lists[i]->value);
				list->frequency = dictionary->lists[i]->frequency;
				list->next = NULL;
				list->prev = NULL;
			}
			else
			{
				ListNode *temp = (ListNode*)malloc(sizeof(ListNode));
				temp->key = malloc((strlen(dictionary->lists[i]->key)+1)*sizeof(char));
				strcpy(temp->key, dictionary->lists[i]->key);
				temp->value = malloc((strlen(dictionary->lists[i]->value)+1)*sizeof(char));
				strcpy(temp->value, dictionary->lists[i]->value);
				temp->frequency = dictionary->lists[i]->frequency;
				temp->next = NULL;
				temp->prev = list;
				list->next = temp;
				list = list->next;
			}
				
				ListNode *aux = dictionary->lists[i]->next;
				if((dictionary->lists[i]->frequency != aux->frequency) || (dictionary->lists[i]->next == start))
				{
					pp = 1;
				}
				else
				{
					dictionary->lists[i] = dictionary->lists[i]->next;
				}
			}			
		}
		dictionary->lists[i] = start;
	}

	if(list->frequency != -1)
	{
		list = head;
		return list;
	}
	else
		return NULL;

}

Dictionary* reverseLists(Dictionary *dictionary) {
	// TODO
	
	int ls, i=0, ds, pp;
	ds = dictionary->N;

	Dictionary *rdictionary = createDictionary(ds);
	for(i=0; i<ds; i++)
	{
		if(dictionary->lists[i]!=NULL)
		{
			ListNode *start = dictionary->lists[i];

			rdictionary->lists[i] = (ListNode*)malloc(sizeof(ListNode));
			rdictionary->lists[i]->key = malloc((strlen(dictionary->lists[i]->key)+1)*sizeof(char));
			strcpy(rdictionary->lists[i]->key, dictionary->lists[i]->key);
			rdictionary->lists[i]->value = malloc((strlen(dictionary->lists[i]->value)+1)*sizeof(char));
			strcpy(rdictionary->lists[i]->value, dictionary->lists[i]->value);
			rdictionary->lists[i]->frequency = dictionary->lists[i]->frequency;
			rdictionary->lists[i]->next = rdictionary->lists[i];
			rdictionary->lists[i]->prev = rdictionary->lists[i];

			if(dictionary->lists[i]->next != dictionary->lists[i])
			{
				dictionary->lists[i] = dictionary->lists[i]->next;

				ListNode *temp = (ListNode*)malloc(sizeof(ListNode));
				temp->key = malloc((strlen(dictionary->lists[i]->key)+1)*sizeof(char));
				strcpy(temp->key, dictionary->lists[i]->key);
				temp->value = malloc((strlen(dictionary->lists[i]->value)+1)*sizeof(char));
				strcpy(temp->value, dictionary->lists[i]->value);
				temp->frequency = dictionary->lists[i]->frequency;
				temp->next = rdictionary->lists[i];
				temp->prev = rdictionary->lists[i];
				rdictionary->lists[i]->next = temp;
				rdictionary->lists[i]->prev = temp;				

				if(dictionary->lists[i]->next != dictionary->lists[i]->prev)
				{
					dictionary->lists[i] = dictionary->lists[i]->next;
					pp = 0;

					while(pp==0)
					{
						if(dictionary->lists[i]->next == start)
						{
						pp = 1;
						}

						ListNode *temp = (ListNode*)malloc(sizeof(ListNode));
						temp->prev = rdictionary->lists[i]->prev;
						temp->next = rdictionary->lists[i]; 
						rdictionary->lists[i]->prev = temp;
						rdictionary->lists[i] = temp->prev;
						rdictionary->lists[i]->next = temp;
						temp->key = malloc((strlen(dictionary->lists[i]->key)+1)*sizeof(char));
						strcpy(temp->key, dictionary->lists[i]->key);
						temp->value = malloc((strlen(dictionary->lists[i]->value)+1)*sizeof(char));
						strcpy(temp->value, dictionary->lists[i]->value);
						temp->frequency = dictionary->lists[i]->frequency;
						rdictionary->lists[i] = temp->next;

						dictionary->lists[i] = dictionary->lists[i]->next;
					}
				}
				else
							dictionary->lists[i] = start;
			}
		
			rSortList(rdictionary, i);
		}

	}

	return rdictionary;
}

void printList(FILE *f, ListNode *list) {
	// TODO

	int i=0;
	int pp=0;
	ListNode *start = list;

	while(pp==0 && list!=NULL)
	{
		if(list->next == NULL)
		{
			pp = 1;
		}

		fprintf(f, "(%s, %s, %d) ", list->key, list->value, list->frequency);
		list = list->next;
	}

	list = start;

	fprintf(f, "\n");

	return;
}

void freeDictionary(Dictionary *dictionary) {
	// TODO
	
	int ds, i;
	ds = dictionary->N;

	for(i=0; i<ds; i++)
	{
		if(dictionary->lists[i]!=NULL)
		{
			freeList(dictionary->lists[i]);
		}
	}
	free(dictionary->lists);
	free(dictionary);
	

	return;
}

void freeList(ListNode *list) {
	// TODO
	if(list!=NULL)
	{
		if(list->prev!=NULL)	
		{
			if(list->next == list)
			{
				free(list->key);
				free(list->value);
				free(list);
			}
			else
			{
				ListNode* aux =  list->prev;
				aux->next = NULL;
				while(list!=NULL)
				{
					ListNode* temp =  list->next;
					free(list->key);
					free(list->value);
					list = temp;
				}
				free(list);
			}
		}
		else 
		{
			if(list->next == NULL)
			{
				free(list->key);
				free(list->value);
				free(list);
			}
			else
			{
				while(list->next!=NULL)
				{
					ListNode* temp =  list->next;
					free(list->key);
					free(list->value);
					list = temp;
				}
				free(list->key);
				free(list->value);
				free(list);
			}
		}
	}
	else
		free(list);
	
	return;
}

#endif
