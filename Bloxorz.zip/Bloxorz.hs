{-# OPTIONS_GHC -Wall #-}
{-# LANGUAGE EmptyDataDecls, MultiParamTypeClasses,
             TypeSynonymInstances, FlexibleInstances,
             InstanceSigs #-}


module Bloxorz where

import ProblemState

import qualified Data.Array as A

{-
    Caracterele ce vor fi printate pentru fiecare tip de obiect din joc 
    Puteți înlocui aceste caractere cu orice, în afară de '\n'.
-}

hardTile :: Char
hardTile = '▒'

softTile :: Char
softTile = '='

block :: Char
block = '▓'

switch :: Char
switch = '±'

emptySpace :: Char
emptySpace = ' '

winningTile :: Char
winningTile = '*'

{-
    Sinonim de tip de date pentru reprezetarea unei perechi (int, int)
    care va reține coordonatele de pe tabla jocului
-}

type Position = (Int, Int)

{-
    Direcțiile în care se poate mișcă blocul de pe tablă
-}

data Tile = HardTile | SoftTile | Block | Switch | EmptySpace | WinningTile deriving (Eq, Ord)

instance Show Tile where
	show HardTile = [hardTile]
	show SoftTile = [softTile]
	show Block = [block]
	show Switch = [switch]
	show EmptySpace = [emptySpace]
	show WinningTile = [winningTile]

data Directions = North | South | West | East
    deriving (Show, Eq, Ord)

{-
    *** TODO ***

    Tip de date care va reprezenta plăcile care alcătuiesc harta și switch-urile
-}

data Cell = Cell
  { pos :: Position
  , tile :: Tile
  , linked :: [Position]
  , active :: Bool
  } deriving (Eq, Ord)

instance Show Cell where
	show (Cell _ tl _ _) = (show tl)

{-
    *** TODO ***

    Tip de date pentru reprezentarea nivelului curent
-}

data Level = Level
	{ cells :: (A.Array Position Cell)
	, player :: (Position, Position)
	, won :: Bool
	, playing :: Bool
	, winT :: Position
	}	deriving (Eq, Ord)

{-
    *** Opțional *** 
  
    Dacă aveți nevoie de o funcționalitate particulară, 
    instantiati explicit clasele Eq și Ord pentru Level. 
    În cazul acesta, eliminați deriving (Eq, Ord) din Level. 
-}

-- instance Eq Level where
--     (==) = undefined

-- instance Ord Level where
--     compare = undefined

{-
    *** TODO ***

    Instantiati Level pe Show. 

    Atenție! String-ul returnat va fi urmat și precedat de un rând nou. 
    În cazul în care jocul este câștigat, la sfârșitul stringului se va mai
    concatena mesajul "Congrats! You won!\n". 
    În cazul în care jocul este pierdut, se va mai concatena "Game Over\n". 
-}

wMessage :: Level -> String
wMessage lvl
	|(won lvl) == True = "Congrats! You won!"
	| otherwise = "Game Over"

instance Show Level where
    show lvl = "\n" ++ unlines [foldl (++) "" [if x == fst (fst (player lvl)) && y == snd (fst (player lvl)) || x == fst (snd (player lvl)) && y == snd (snd (player lvl)) 
                								then show Block 
                									else if x == i && y == j && (playing lvl) == False
                										then show ((cells lvl) A.! (x, y)) ++ "\n" ++ wMessage lvl
                										else show ((cells lvl) A.! (x, y)) | x <- [0..i]] | y <- [0..j]]					
                where (i, j) = snd (A.bounds (cells lvl))

{-
    *** TODO ***

    Primește coordonatele colțului din dreapta jos a hârtii și poziția inițială a blocului.
    Întoarce un obiect de tip Level gol.
    Implicit, colțul din stânga sus este (0, 0).
-}

emptyLevel :: Position -> Position -> Level
emptyLevel border p_pos = Level {cells = A.array ((0,0),(snd border, fst border)) [((i,j), Cell {pos=(i,j), tile=EmptySpace, linked=[],active = True})
										 | i<-[0..(snd border)], j<-[0..(fst border)]]
										, player = ((snd p_pos, fst p_pos), (snd p_pos, fst p_pos)), winT = (0,0), playing=True, won=False} 

{-
    *** TODO ***

    Adaugă o celulă de tip Tile în nivelul curent.
    Parametrul char descrie tipul de tile adăugat: 
        'H' pentru tile hard 
        'S' pentru tile soft 
        'W' pentru winning tile 
-}

addTile :: Char -> Position -> Level -> Level
addTile tl poz lvl
	| tl == 'H' = Level {cells = (cells lvl)A.//[((snd poz, fst poz),Cell{tile = HardTile, pos=(snd poz,fst poz), linked=[],active = True})]
									, player = (player lvl), winT = (winT lvl), playing=True, won=False}
	| tl == 'S' = Level {cells = (cells lvl)A.//[((snd poz, fst poz),Cell{tile = SoftTile, pos=(snd poz,fst poz), linked=[],active = True})]
									, player = (player lvl), winT = (winT lvl), playing=True, won=False}
	| tl == 'W' = Level {cells = (cells lvl)A.//[((snd poz, fst poz),Cell{tile = WinningTile, pos=(snd poz,fst poz), linked=[],active = True})]
									, player = (player lvl), winT = poz, playing=True, won=False}
	| otherwise = lvl

{-
    *** TODO ***

    Adaugă o celulă de tip Swtich în nivelul curent.
    Va primi poziția acestuia și o listă de Position
    ce vor desemna pozițiile în care vor apărea sau 
    dispărea Hard Cells în momentul activării/dezactivării
    switch-ului.
-}

addSwitch :: Position -> [Position] -> Level -> Level
addSwitch poz actv lvl= Level {cells = (cells lvl)A.//[((snd poz, fst poz),Cell{tile = Switch, pos=(snd poz,fst poz), linked=actv,active = False})]
									, player = (player lvl), winT = (winT lvl), playing=True, won=False}

{-
    === MOVEMENT ===
-}

{-
    *** TODO ***

    Activate va verifica dacă mutarea blocului va activa o mecanică specifică. 
    În funcție de mecanica activată, vor avea loc modificări pe hartă. 
-}
activateH :: Level -> Tile -> [Position] -> Level
activateH lvl tl [] = lvl
activateH lvl tl (x:xs) = activateH Level {cells = (cells lvl)A.//[((snd x, fst x),Cell{tile = tl, pos=(snd x,fst x), linked=[],active = True})]
									, player = (player lvl), winT = (winT lvl), playing=True, won=False} tl xs

updateCell :: Cell -> Level -> Bool -> Level
updateCell c lvl b = Level {cells = (cells lvl)A.//[((pos c),Cell{tile = (tile c), pos=(pos c), linked=(linked c),active = b})]
									, player = (player lvl), winT = (winT lvl), playing=True, won=False}

activate :: Cell -> Level -> Level
activate c lvl
	| (tile c) == EmptySpace = Level {cells = (cells lvl), player = (player lvl), winT = (winT lvl), playing=False, won=False}
	| (tile c) == WinningTile && fst (player lvl) == snd (player lvl) = Level {cells = (cells lvl), player = (player lvl), winT = (winT lvl), playing=False, won=True}
	| (tile c) == SoftTile && fst (player lvl) == snd (player lvl) = Level {cells = (cells lvl), player = (player lvl), winT = (winT lvl), playing=False, won=False}
	| (tile c) == Switch && (active c) == False = (updateCell c (activateH lvl HardTile (linked c)) True)
	| (tile c) == Switch && (active c) == True = (updateCell c (activateH lvl EmptySpace (linked c)) False)
	| otherwise = lvl

activateCellsH :: [Cell] -> Level -> Level
activateCellsH [] lvl = lvl
activateCellsH (x:xs) lvl = activateCellsH xs (activate x lvl)

activateCells :: Level -> Level
activateCells lvl
	| fst (player lvl ) == snd (player lvl) = activateCellsH [(cells lvl)A.!fst(player lvl)] lvl
	| otherwise = activateCellsH [(cells lvl)A.!fst(player lvl),(cells lvl)A.!snd(player lvl)] lvl

{-
    *** TODO ***

    Mișcarea blocului în una din cele 4 direcții 
    Hint: Dacă jocul este deja câștigat sau pierdut, puteți lăsa nivelul neschimbat.
-}

moveW :: Level -> Level
moveW lvl
	| fst (player lvl) == snd (player lvl) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)) - 1, snd(fst(player lvl))), (fst(snd(player lvl)) - 2, snd(snd(player lvl)))), winT = (winT lvl), playing=True, won=False}
	| fst (fst(player lvl)) == fst (snd(player lvl)) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)) - 1, snd(fst(player lvl))), (fst(snd(player lvl)) - 1, snd(snd(player lvl)))), winT = (winT lvl), playing=True, won=False}
	| snd (fst(player lvl)) == snd (snd(player lvl)) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)) - 2, snd(fst(player lvl))), (fst(snd(player lvl)) - 1, snd(snd(player lvl)))), winT = (winT lvl), playing=True, won=False}
	| otherwise = lvl

moveE :: Level -> Level
moveE lvl
	| fst (player lvl) == snd (player lvl) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)) + 2, snd(fst(player lvl))), (fst(snd(player lvl)) + 1, snd(snd(player lvl)))), winT = (winT lvl), playing=True, won=False}
	| fst (fst(player lvl)) == fst (snd(player lvl)) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)) + 1, snd(fst(player lvl))), (fst(snd(player lvl)) + 1, snd(snd(player lvl)))), winT = (winT lvl), playing=True, won=False}
	| snd (fst(player lvl)) == snd (snd(player lvl)) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)) + 1, snd(fst(player lvl))), (fst(snd(player lvl)) + 2, snd(snd(player lvl)))), winT = (winT lvl), playing=True, won=False}
	| otherwise = lvl

moveN :: Level -> Level
moveN lvl
	| fst (player lvl) == snd (player lvl) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)), snd(fst(player lvl)) - 1), (fst(snd(player lvl)), snd(snd(player lvl)) - 2)), winT = (winT lvl), playing=True, won=False}
	| fst (fst(player lvl)) == fst (snd(player lvl)) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)), snd(fst(player lvl)) - 2), (fst(snd(player lvl)), snd(snd(player lvl)) - 1)), winT = (winT lvl), playing=True, won=False}
	| snd (fst(player lvl)) == snd (snd(player lvl)) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)), snd(fst(player lvl)) - 1), (fst(snd(player lvl)), snd(snd(player lvl)) - 1)), winT = (winT lvl), playing=True, won=False}
	| otherwise = lvl

moveS :: Level -> Level
moveS lvl
	| fst (player lvl) == snd (player lvl) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)), snd(fst(player lvl)) + 2), (fst(snd(player lvl)), snd(snd(player lvl)) + 1)), winT = (winT lvl), playing=True, won=False}
	| fst (fst(player lvl)) == fst (snd(player lvl)) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)), snd(fst(player lvl)) + 1), (fst(snd(player lvl)), snd(snd(player lvl)) + 2)), winT = (winT lvl), playing=True, won=False}
	| snd (fst(player lvl)) == snd (snd(player lvl)) = Level {cells = (cells lvl), player = ((fst(fst(player lvl)), snd(fst(player lvl)) + 1), (fst(snd(player lvl)), snd(snd(player lvl)) + 1)), winT = (winT lvl), playing=True, won=False}
	| otherwise = lvl

moveH :: Directions -> Level -> Level
moveH d lvl
	| d == North = moveN lvl
	| d == South = moveS lvl
	| d == West = moveW lvl
	| d == East = moveE lvl
	| otherwise = lvl

move :: Directions -> Level -> Level
move d lvl = activateCells (moveH d lvl)
{-
    *** TODO ***

    Va returna True dacă jocul nu este nici câștigat, nici pierdut.
    Este folosită în cadrul Interactive.
-}

continueGame :: Level -> Bool
continueGame lvl = (playing lvl)

{-
    *** TODO ***

    Instanțiați clasa `ProblemState` pentru jocul nostru. 
  
    Hint: Un level câștigat nu are succesori! 
    De asemenea, puteți ignora succesorii care 
    duc la pierderea unui level.
-}

newState:: Directions -> Level -> (Directions, Level)
newState d lvl = (d, move d lvl)

successorsH :: [Directions] -> Level -> [(Directions, Level)] -> [(Directions, Level)]
successorsH [] lvl l = l
successorsH (x:xs) lvl l
	| (playing (move x lvl)) == True = successorsH xs lvl ([newState x lvl] ++ l)
	| (won (move x lvl)) == True = successorsH xs lvl ([newState x lvl] ++ l)
	| otherwise = successorsH xs lvl l

instance ProblemState Level Directions where
    successors lvl = successorsH [North,South,East,West] lvl []

    isGoal lvl = (won lvl)

    -- Doar petru BONUS
    -- heuristic = undefined
